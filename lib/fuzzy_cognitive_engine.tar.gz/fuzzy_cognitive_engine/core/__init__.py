# Fuzzy Cognitive Engine - Core modules
