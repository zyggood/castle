"""
Layer 1: 模糊不确定性评估
从 token 级 logits 中提取不确定性信号，模糊化后用 OWA 融合
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, Optional
from .fuzzy_math import (
    FuzzySet, owa_conservative, owa_optimistic, owa,
    FuzzyRule, FuzzyRuleEngine, centroid, max_membership
)


class UncertaintyAssessor:
    """模糊不确定性评估器"""

    def __init__(self, model_wrapper=None):
        self.model_wrapper = model_wrapper
        self.rule_engine = self._build_rules()

    def _build_rules(self) -> FuzzyRuleEngine:
        """构建模糊推理规则"""
        engine = FuzzyRuleEngine()

        # R1: 高熵 + 低一致性 → 非常不确定
        engine.add_rule(FuzzyRule(
            conditions=[("entropy", "high", 1.0), ("consistency", "low", 1.0)],
            conclusion={"target": "uncertainty", "value": "very_uncertain"}
        ))

        # R2: 低熵 + 高一致性 → 非常确定
        engine.add_rule(FuzzyRule(
            conditions=[("entropy", "low", 1.0), ("consistency", "high", 1.0)],
            conclusion={"target": "uncertainty", "value": "very_certain"}
        ))

        # R3: 中等熵 → 中等不确定
        engine.add_rule(FuzzyRule(
            conditions=[("entropy", "medium", 1.0)],
            conclusion={"target": "uncertainty", "value": "uncertain"}
        ))

        # R4: 高集中度 → 确定
        engine.add_rule(FuzzyRule(
            conditions=[("concentration", "high", 1.0)],
            conclusion={"target": "uncertainty", "value": "certain"}
        ))

        # R5: 低集中度 → 不确定
        engine.add_rule(FuzzyRule(
            conditions=[("concentration", "low", 1.0)],
            conclusion={"target": "uncertainty", "value": "uncertain"}
        ))

        # R6: 低一致性单独 → 不确定
        engine.add_rule(FuzzyRule(
            conditions=[("consistency", "low", 1.0)],
            conclusion={"target": "uncertainty", "value": "uncertain"}
        ))

        return engine

    # ========================================================
    # 信号提取
    # ========================================================

    def compute_token_entropy(self, logits: torch.Tensor) -> np.ndarray:
        """计算每步 token 的归一化熵"""
        probs = F.softmax(logits, dim=-1)
        vocab_size = probs.shape[-1]
        max_entropy = np.log(vocab_size)  # 均匀分布的最大熵

        entropy = -(probs * torch.log(probs + 1e-10)).sum(dim=-1)
        normalized = entropy / max_entropy  # 归一化到 0-1
        return normalized.numpy()

    def compute_topk_concentration(self, logits: torch.Tensor, k: int = 5) -> float:
        """计算 top-k 概率集中度 (越高越确定)"""
        probs = F.softmax(logits, dim=-1)
        topk_probs = torch.topk(probs, k=min(k, probs.shape[-1]), dim=-1).values
        # 每步取 top-k 概率和
        concentration = topk_probs.mean(dim=-1).mean().item()
        return concentration

    def compute_self_consistency(self, responses: list) -> float:
        """
        自一致性: 多次采样结果的一致程度
        返回 0-1, 1 = 完全一致
        """
        if len(responses) <= 1:
            return 1.0

        # 简化: 用前 20 个字符的匹配率衡量
        # (完整实现可用 embedding 相似度)
        prefixes = [r[:50].lower().strip() for r in responses]
        reference = prefixes[0]

        matches = sum(1 for p in prefixes[1:] if self._text_similarity(reference, p) > 0.6)
        consistency = (matches + 1) / len(prefixes)  # +1 包含参考本身
        return min(consistency, 1.0)

    def _text_similarity(self, a: str, b: str) -> float:
        """简单文本相似度 (Jaccard on chars)"""
        if not a or not b:
            return 0.0
        set_a = set(a)
        set_b = set(b)
        intersection = len(set_a & set_b)
        union = len(set_a | set_b)
        return intersection / (union + 1e-10)

    # ========================================================
    # 模糊化
    # ========================================================

    def fuzzify_entropy(self, entropy: float) -> Dict[str, float]:
        """将 token 熵模糊化为 3 级 (熵越高越不确定)"""
        return {
            "low":    max(0, min(1, (0.5 - entropy) / 0.25)) if entropy < 0.5 else 0,
            "medium": max(0, min(1, 1 - abs(entropy - 0.55) / 0.2)),
            "high":   max(0, min(1, (entropy - 0.6) / 0.25)) if entropy > 0.6 else 0,
        }

    def fuzzify_concentration(self, concentration: float) -> Dict[str, float]:
        """将集中度模糊化 (集中度越高越确定)"""
        return {
            "low":    max(0, min(1, (0.5 - concentration) / 0.2)) if concentration < 0.5 else 0,
            "medium": max(0, min(1, 1 - abs(concentration - 0.55) / 0.2)),
            "high":   max(0, min(1, (concentration - 0.6) / 0.25)) if concentration > 0.6 else 0,
        }

    def fuzzify_consistency(self, consistency: float) -> Dict[str, float]:
        """将自一致性模糊化"""
        return {
            "low":    max(0, min(1, (0.5 - consistency) / 0.25)) if consistency < 0.5 else 0,
            "medium": max(0, min(1, 1 - abs(consistency - 0.55) / 0.2)),
            "high":   max(0, min(1, (consistency - 0.6) / 0.25)) if consistency > 0.6 else 0,
        }

    # ========================================================
    # 主评估流程
    # ========================================================

    def assess(self, logits: torch.Tensor, impression: str,
               self_consistency: float = None) -> Dict:
        """
        主入口: 评估模型输出的不确定性

        Args:
            logits: 每步生成的 logits (seq_len, vocab_size)
            impression: 模型生成的文本
            self_consistency: 自一致性分数 (可选, None 则跳过)

        Returns:
            完整的不确定性评估结果
        """
        # --- 提取原始信号 ---
        token_entropy = self.compute_token_entropy(logits)
        avg_entropy = float(token_entropy.mean())
        concentration = self.compute_topk_concentration(logits)

        signals = {
            "avg_token_entropy": round(avg_entropy, 4),
            "max_token_entropy": round(float(token_entropy.max()), 4),
            "topk_concentration": round(concentration, 4),
        }

        if self_consistency is not None:
            signals["self_consistency"] = round(self_consistency, 4)
        else:
            # 没有一致性数据时，用熵和集中度
            self_consistency = 1.0 - avg_entropy  # 近似
            signals["self_consistency"] = round(self_consistency, 4)

        # --- 模糊化 ---
        fuzzy_inputs = {
            "entropy": self.fuzzify_entropy(avg_entropy),
            "concentration": self.fuzzify_concentration(concentration),
            "consistency": self.fuzzify_consistency(self_consistency),
        }

        # --- 模糊规则推理 ---
        rule_results = self.rule_engine.evaluate_all(fuzzy_inputs)

        # --- OWA 融合 ---
        # 综合各信号的"不确定度"
        uncertainty_scores = []

        # 熵的不确定度: 熵越高越不确定
        uncertainty_scores.append(avg_entropy)

        # 集中度的不确定度: 集中度越低越不确定
        uncertainty_scores.append(1.0 - concentration)

        # 一致性的不确定度: 一致性越低越不确定
        uncertainty_scores.append(1.0 - self_consistency)

        # 用保守 OWA (更重视高不确定度)
        fused_uncertainty = owa_conservative(uncertainty_scores)

        # 转为置信度
        fused_confidence = 1.0 - fused_uncertainty

        # --- 用规则结果修正 ---
        if "uncertainty" in rule_results:
            uncertainty_profile = rule_results["uncertainty"]
            # 去模糊化: 重心法
            centers = {
                "very_certain": 0.95,
                "certain": 0.72,
                "uncertain": 0.45,
                "very_uncertain": 0.15,
            }
            rule_confidence = centroid(uncertainty_profile, centers)

            # OWA 融合 OWA 结果和规则结果
            fused_confidence = owa([fused_confidence, rule_confidence],
                                   weights=[0.6, 0.4])

        # 构建不确定性画像
        uncertainty_profile = FuzzySet.uncertainty_profile(fused_confidence)

        return {
            "signals": signals,
            "fuzzy_inputs": {k: {kk: round(vv, 3) for kk, vv in v.items()}
                             for k, v in fuzzy_inputs.items()},
            "uncertainty_profile": {k: round(v, 3) for k, v in uncertainty_profile.items()},
            "fused_confidence": round(fused_confidence, 4),
            "should_query": fused_confidence < 0.65,
            "confidence_label": max_membership(uncertainty_profile),
        }
