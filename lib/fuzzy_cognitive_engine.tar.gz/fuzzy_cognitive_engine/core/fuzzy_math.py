"""
模糊数学工具库
提供隶属函数、OWA 聚合、t-norm/t-conorm 等基础运算
"""

import numpy as np
from typing import List, Callable, Dict


# ============================================================
# 隶属函数 (Membership Functions)
# ============================================================

def trimf(x: float, a: float, b: float, c: float) -> float:
    """三角隶属函数
    a: 左端点, b: 峰值, c: 右端点
    """
    if x <= a or x >= c:
        return 0.0
    elif x <= b:
        return (x - a) / (b - a + 1e-10)
    else:
        return (c - x) / (c - b + 1e-10)


def trapmf(x: float, a: float, b: float, c: float, d: float) -> float:
    """梯形隶属函数
    a: 左端, b: 左平台起点, c: 右平台终点, d: 右端
    """
    if x <= a or x >= d:
        return 0.0
    elif x <= b:
        return (x - a) / (b - a + 1e-10)
    elif x <= c:
        return 1.0
    else:
        return (d - x) / (d - c + 1e-10)


def gaussian_mf(x: float, mean: float, sigma: float) -> float:
    """高斯隶属函数"""
    return float(np.exp(-((x - mean) ** 2) / (2 * sigma ** 2 + 1e-10)))


def sigmoid_mf(x: float, a: float, c: float) -> float:
    """S 型隶属函数 (单调递增)
    a: 斜率, c: 中心点
    """
    return 1.0 / (1.0 + np.exp(-a * (x - c)))


# ============================================================
# 隶属函数预设集合
# ============================================================

class FuzzySet:
    """预定义的模糊集合，用于常见的语义标签"""

    @staticmethod
    def uncertainty_profile(x: float) -> Dict[str, float]:
        """不确定性画像: 输入 0-1 的置信度，输出 4 级隶属度"""
        return {
            "very_certain":   trapmf(x, 0.85, 0.95, 1.0, 1.0),
            "certain":        trimf(x, 0.55, 0.72, 0.88),
            "uncertain":      trimf(x, 0.25, 0.45, 0.65),
            "very_uncertain": trapmf(x, 0.0, 0.0, 0.15, 0.35),
        }

    @staticmethod
    def similarity_profile(x: float) -> Dict[str, float]:
        """语义相似度画像: 输入 0-1 的相似度"""
        return {
            "strong_match":   trimf(x, 0.65, 0.85, 1.0),
            "partial_match":  trimf(x, 0.3, 0.5, 0.7),
            "weak_match":     trimf(x, 0.1, 0.25, 0.4),
            "mismatch":       trapmf(x, 0.0, 0.0, 0.1, 0.25),
        }

    @staticmethod
    def confidence_label(x: float) -> Dict[str, float]:
        """置信度标签"""
        return {
            "high":    trimf(x, 0.65, 0.8, 1.0),
            "medium":  trimf(x, 0.35, 0.5, 0.7),
            "low":     trimf(x, 0.1, 0.25, 0.4),
            "uncertain": trapmf(x, 0.0, 0.0, 0.05, 0.15),
        }


# ============================================================
# 聚合算子 (Aggregation Operators)
# ============================================================

def owa(values: List[float], weights: List[float] = None) -> float:
    """
    OWA (Ordered Weighted Averaging)
    对值排序后加权平均
    weights 降序 → 偏乐观 (重视高值)
    weights 升序 → 偏悲观 (重视低值)
    """
    n = len(values)
    if n == 0:
        return 0.0
    if weights is None:
        # 默认: 均匀权重 (等价于算术平均)
        weights = [1.0 / n] * n

    sorted_vals = sorted(values, reverse=True)
    return sum(v * w for v, w in zip(sorted_vals, weights[:n]))


def owa_conservative(values: List[float]) -> float:
    """保守 OWA: 更重视低值 (高不确定性)"""
    n = len(values)
    # 权重递增 → 排序后降序对应低值获高权重
    weights = [2 * (i + 1) / (n * (n + 1)) for i in range(n)]
    return owa(values, weights)


def owa_optimistic(values: List[float]) -> float:
    """乐观 OWA: 更重视高值 (低不确定性)"""
    n = len(values)
    weights = [2 * (n - i) / (n * (n + 1)) for i in range(n)]
    return owa(values, weights)


# ============================================================
# T-norm / T-conorm (模糊交/并)
# ============================================================

def t_norm_product(a: float, b: float) -> float:
    """乘积 t-norm"""
    return a * b


def t_norm_min(a: float, b: float) -> float:
    """最小值 t-norm (Gödel)"""
    return min(a, b)


def t_norm_lukasiewicz(a: float, b: float) -> float:
    """Lukasiewicz t-norm"""
    return max(0, a + b - 1)


def t_conorm_max(a: float, b: float) -> float:
    """最大值 t-conorm"""
    return max(a, b)


def t_conorm_probabilistic(a: float, b: float) -> float:
    """概率和 t-conorm"""
    return a + b - a * b


# ============================================================
# 去模糊化 (Defuzzification)
# ============================================================

def centroid(values: Dict[str, float], centers: Dict[str, float]) -> float:
    """
    重心法去模糊化
    values: 各模糊集合的隶属度
    centers: 各模糊集合的代表点 (重心)
    """
    numerator = sum(values[k] * centers[k] for k in values)
    denominator = sum(values[k] for k in values) + 1e-10
    return numerator / denominator


def max_membership(values: Dict[str, float]) -> str:
    """最大隶属度法: 返回隶属度最高的标签"""
    return max(values, key=values.get)


# ============================================================
# 模糊规则引擎
# ============================================================

class FuzzyRule:
    """单条模糊规则"""

    def __init__(self, conditions: List[tuple], conclusion: Dict):
        """
        conditions: [(input_key, fuzzy_label, weight), ...]
        示例: [("entropy", "high", 1.0), ("consistency", "low", 0.8)]
        conclusion: {"target": "uncertainty", "value": "very_uncertain"}
        """
        self.conditions = conditions
        self.conclusion = conclusion

    def evaluate(self, inputs: Dict[str, Dict[str, float]]) -> float:
        """计算规则的激活强度"""
        strengths = []
        for input_key, label, weight in self.conditions:
            if input_key in inputs and label in inputs[input_key]:
                strengths.append(inputs[input_key][label] * weight)
            else:
                strengths.append(0.0)

        # 用 t-norm (乘积) 合并多个条件
        result = 1.0
        for s in strengths:
            result = t_norm_product(result, s)
        return result


class FuzzyRuleEngine:
    """模糊规则引擎"""

    def __init__(self):
        self.rules: List[FuzzyRule] = []

    def add_rule(self, rule: FuzzyRule):
        self.rules.append(rule)

    def evaluate_all(self, inputs: Dict[str, Dict[str, float]]) -> Dict[str, Dict[str, float]]:
        """执行所有规则，聚合结论"""
        # 初始化目标
        targets: Dict[str, Dict[str, float]] = {}

        for rule in self.rules:
            strength = rule.evaluate(inputs)
            target = rule.conclusion["target"]
            value = rule.conclusion["value"]

            if target not in targets:
                targets[target] = {}

            # 取 max (t-conorm) 聚合相同结论
            if value not in targets[target]:
                targets[target][value] = 0.0
            targets[target][value] = max(targets[target][value], strength)

        return targets
