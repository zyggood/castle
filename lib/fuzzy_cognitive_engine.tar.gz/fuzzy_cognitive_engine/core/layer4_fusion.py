"""
Layer 4: 模糊融合输出
综合所有层的结果，生成最终答案
"""

from typing import Dict, Any, Optional
from .fuzzy_math import (
    FuzzySet, owa, owa_conservative, centroid, max_membership,
    FuzzyRule, FuzzyRuleEngine
)


class FuzzyFusionOutput:
    """模糊融合输出器"""

    def __init__(self):
        self.rule_engine = self._build_fusion_rules()
        self.confidence_centers = {
            "high": 0.85,
            "medium": 0.5,
            "low": 0.25,
            "uncertain": 0.1,
        }

    def _build_fusion_rules(self) -> FuzzyRuleEngine:
        """构建融合规则"""
        engine = FuzzyRuleEngine()

        # 规则1: 高印象置信 + 强外部匹配 → 高置信
        engine.add_rule(FuzzyRule(
            conditions=[("impression_confidence", "high", 1.0),
                        ("external_match", "strong", 1.0)],
            conclusion={"target": "final_confidence", "value": "high"}
        ))

        # 规则2: 中印象置信 + 有外部证据 → 中置信
        engine.add_rule(FuzzyRule(
            conditions=[("impression_confidence", "medium", 1.0),
                        ("external_support", "present", 1.0)],
            conclusion={"target": "final_confidence", "value": "medium"}
        ))

        # 规则3: 低印象置信 + 弱外部支持 → 低置信
        engine.add_rule(FuzzyRule(
            conditions=[("impression_confidence", "low", 1.0),
                        ("external_support", "weak", 1.0)],
            conclusion={"target": "final_confidence", "value": "low"}
        ))

        # 规则4: 印象和外部冲突 → 低置信但外部优先
        engine.add_rule(FuzzyRule(
            conditions=[("external_match", "mismatch", 1.0)],
            conclusion={"target": "final_confidence", "value": "medium"}
        ))

        # 规则5: 无外部支持 + 低印象置信 → 不确定
        engine.add_rule(FuzzyRule(
            conditions=[("impression_confidence", "low", 1.0),
                        ("external_support", "none", 1.0)],
            conclusion={"target": "final_confidence", "value": "uncertain"}
        ))

        return engine

    def fuse(self,
             impression: str,
             impression_confidence: float,
             external_results: Optional[Dict] = None,
             verification: Optional[Dict] = None) -> Dict[str, Any]:
        """
        融合所有信息生成最终输出
        """
        # --- 准备模糊输入 ---
        imp_profile = FuzzySet.uncertainty_profile(impression_confidence)

        fuzzy_inputs = {
            "impression_confidence": {
                "high": imp_profile["very_certain"] + imp_profile["certain"],
                "medium": imp_profile["uncertain"],
                "low": imp_profile["very_uncertain"],
            }
        }

        # 外部证据评估
        has_external = external_results and any(
            r.get("found", False) or r.get("answer") is not None
            for r in external_results.get("results", {}).values()
        )
        best_relevance = 0.0
        external_answer = None
        external_source = None

        if has_external:
            for skill_name, result in external_results["results"].items():
                rel = result.get("relevance", 0)
                if rel > best_relevance and result.get("answer"):
                    best_relevance = rel
                    external_answer = result["answer"]
                    external_source = skill_name

        # 外部支持模糊化
        if best_relevance > 0.7:
            fuzzy_inputs["external_support"] = {"present": 0.9, "weak": 0.1, "none": 0}
        elif best_relevance > 0.3:
            fuzzy_inputs["external_support"] = {"present": 0.5, "weak": 0.5, "none": 0}
        elif has_external:
            fuzzy_inputs["external_support"] = {"present": 0.2, "weak": 0.6, "none": 0.2}
        else:
            fuzzy_inputs["external_support"] = {"present": 0, "weak": 0.2, "none": 0.8}

        # 验证匹配度
        if verification:
            match = verification.get("match_profile", {})
            fuzzy_inputs["external_match"] = {
                "strong": match.get("strong_match", 0),
                "partial": match.get("partial_match", 0),
                "mismatch": match.get("mismatch", 0),
            }
        else:
            fuzzy_inputs["external_match"] = {"strong": 0, "partial": 0, "mismatch": 0}

        # --- 规则推理 ---
        rule_results = self.rule_engine.evaluate_all(fuzzy_inputs)

        # --- OWA 融合最终置信度 ---
        if "final_confidence" in rule_results:
            fc = rule_results["final_confidence"]
            final_confidence = centroid(fc, self.confidence_centers)
        else:
            # 退化方案: 无外部证据时完全依赖印象置信度
            if has_external and best_relevance > 0:
                final_confidence = owa(
                    [impression_confidence, best_relevance],
                    weights=[0.6, 0.4]
                )
            else:
                # 无外部信息，直接用印象置信度（不要让它被 0 平均掉）
                final_confidence = impression_confidence * 0.8  # 略降因为未经验证

        # 验证修正
        if verification:
            final_confidence = max(0, min(1,
                final_confidence + verification.get("confidence_boost", 0)
            ))

        # --- 确定答案来源和内容 ---
        if verification and verification["source_priority"] == "evidence_only" and external_answer:
            answer = external_answer
            source = f"外部检索 ({external_source})"
            note = "⚠️ 模型印象与外部信息不一致，已使用外部来源"
        elif verification and verification["source_priority"] == "both" and external_answer:
            # 两者一致，增强输出
            answer = external_answer
            source = f"模型印象 + 外部检索 ({external_source}) 双重确认"
            note = "✅ 模型印象与外部来源一致"
        elif has_external and external_answer and final_confidence < 0.6:
            answer = external_answer
            source = f"外部检索 ({external_source})"
            note = "📌 模型不确定，使用外部检索结果"
        elif final_confidence > 0.6:
            answer = impression
            source = "模型印象"
            note = "💡 模型对答案较为确定"
        else:
            if external_answer:
                answer = external_answer
                source = f"外部检索 ({external_source})"
                note = "📌 模型不确定，使用外部检索结果"
            else:
                answer = impression
                source = "模型印象 (低置信)"
                note = "⚠️ 无外部信息可参考，以下答案置信度较低"

        # 置信度标签
        confidence_profile = FuzzySet.confidence_label(final_confidence)
        confidence_label = max_membership(confidence_profile)

        return {
            "answer": answer,
            "confidence": round(final_confidence, 4),
            "confidence_label": confidence_label,
            "confidence_profile": {k: round(v, 3) for k, v in confidence_profile.items()},
            "source": source,
            "note": note,
            "external_answer": external_answer,
            "verification": verification,
            "fuzzy_inputs": {k: {kk: round(vv, 3) for kk, vv in v.items()}
                             for k, v in fuzzy_inputs.items()},
        }
