"""
Layer 0: 印象生成
加载模型，凭"记忆"回答问题，收集 token 级 logits 供后续分析
"""

import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer
from typing import Dict, Optional


class ImpressionGenerator:
    """模型印象生成器"""

    def __init__(self, model_name: str = "Qwen/Qwen2.5-0.5B"):
        print(f"[Layer 0] 加载模型: {model_name}")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float32,
            device_map="cpu",
            trust_remote_code=True
        )
        self.model.eval()
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        print(f"[Layer 0] 模型加载完成")

    def generate_impression(self, question: str, max_new_tokens: int = 200) -> Dict:
        """
        生成模型印象
        返回: 印象文本 + 每步的 logits
        """
        # 格式化 prompt
        prompt = f"问题: {question}\n回答:"

        inputs = self.tokenizer(prompt, return_tensors="pt")
        input_len = inputs["input_ids"].shape[1]

        # 生成并收集 logits
        all_logits = []
        generated_ids = inputs["input_ids"].clone()

        with torch.no_grad():
            for _ in range(max_new_tokens):
                outputs = self.model(generated_ids)
                next_logits = outputs.logits[:, -1, :]  # 最后一个 token 的 logits
                all_logits.append(next_logits)

                # 采样下一个 token (greedy)
                next_token = torch.argmax(next_logits, dim=-1, keepdim=True)
                generated_ids = torch.cat([generated_ids, next_token], dim=-1)

                # 遇到 eos 停止
                if next_token.item() == self.tokenizer.eos_token_id:
                    break

        # 解码生成部分
        generated_part = generated_ids[0, input_len:]
        impression = self.tokenizer.decode(generated_part, skip_special_tokens=True)

        # 堆叠 logits: (seq_len, vocab_size)
        logits_tensor = torch.cat(all_logits, dim=0)

        return {
            "question": question,
            "prompt": prompt,
            "impression": impression.strip(),
            "logits": logits_tensor,
            "generated_ids": generated_part,
            "n_tokens": len(all_logits),
        }

    def generate_multiple(self, question: str, n_samples: int = 3,
                          max_new_tokens: int = 150, temperature: float = 0.7) -> list:
        """多次采样生成 (用于自一致性检测)"""
        prompt = f"问题: {question}\n回答:"
        inputs = self.tokenizer(prompt, return_tensors="pt")
        input_len = inputs["input_ids"].shape[1]
        results = []

        with torch.no_grad():
            for i in range(n_samples):
                output = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=True,
                    temperature=temperature,
                    top_p=0.9,
                    pad_token_id=self.tokenizer.pad_token_id,
                )
                text = self.tokenizer.decode(output[0, input_len:], skip_special_tokens=True)
                results.append(text.strip())

        return results
