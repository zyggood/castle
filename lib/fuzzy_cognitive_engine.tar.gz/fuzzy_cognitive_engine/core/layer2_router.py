"""
Layer 2: 模糊技能路由
对问题进行模糊分类，按隶属度加权路由到不同技能
"""

import re
import sys
import os
from typing import Dict, Any, List
from .fuzzy_math import trimf, t_conorm_max

# 动态导入 skills
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from skills.base_skill import BaseSkill


class FuzzySkillRouter:
    """模糊技能路由器"""

    def __init__(self, skills: Dict[str, BaseSkill]):
        self.skills = skills
        self.classifiers = self._build_classifiers()

    def _build_classifiers(self) -> Dict[str, Dict]:
        """构建技能分类器 (基于关键词 + 模糊隶属函数)"""
        return {
            "knowledge_rag": {
                "keywords": {
                    "是什么": 2, "什么是": 2, "怎么理解": 1.5, "解释": 1.5,
                    "区别": 1.5, "如何工作": 1.5, "原理": 1.5,
                    "GIL": 2, "装饰器": 2, "生成器": 2, "迭代器": 2,
                    "异步": 1.5, "async": 1.5, "类型注解": 2,
                    "上下文管理器": 2, "with": 1, "设计模式": 1.5,
                    "数据结构": 1.5, "排序": 1, "HTTP": 1,
                    "正则": 1.5, "虚拟环境": 1.5, "内存": 1,
                    "复杂度": 1.5, "时间复杂度": 2,
                    "python": 1, "Python": 1, "编程": 1, "代码": 1, "函数": 1,
                    "list": 1, "dict": 1, "set": 1, "tuple": 1,
                },
                "mf": lambda score: min(score / 8.0, 1.0),
            },
            "code_exec": {
                "keywords": {
                    "计算": 2, "算": 1.5, "求": 1.5, "等于": 1.5,
                    "运行": 1.5, "执行": 1.5, "跑一下": 2,
                    "结果是": 1, "多少": 1.5, "怎么算": 2,
                    "实现": 1, "写一个": 1.5, "代码": 1.5,
                    "阶乘": 2, "斐波那契": 2, "fibonacci": 2,
                    "排序算法": 2, "递归": 1.5,
                    "for 循环": 1, "while": 1, "遍历": 1,
                    "验证": 1, "测试": 1, "debug": 1.5,
                },
                "mf": lambda score: min(score / 8.0, 1.0),
            },
            "ask_human": {
                "keywords": {
                    "你觉得": 2, "你认为": 2, "推荐": 1.5,
                    "偏好": 2, "喜欢": 1.5, "哪个好": 2,
                    "帮我选": 2, "意见": 1.5, "建议": 1,
                },
                "mf": lambda score: min(score / 5.0, 1.0),
            },
        }

    def classify(self, query: str) -> Dict[str, float]:
        """模糊分类: 输出每个技能的隶属度"""
        scores = {}

        for skill_name, classifier in self.classifiers.items():
            raw_score = 0
            for keyword, weight in classifier["keywords"].items():
                if keyword.lower() in query.lower():
                    raw_score += weight

            # 通过隶属函数映射到 0-1
            membership = classifier["mf"](raw_score)
            scores[skill_name] = round(membership, 3)

        return scores

    def route(self, query: str, uncertainty_profile: Dict) -> Dict[str, Any]:
        """
        模糊路由: 按隶属度加权执行技能

        Args:
            query: 用户问题
            uncertainty_profile: 来自 Layer 1 的不确定性画像

        Returns:
            各技能的执行结果
        """
        # 模糊分类
        skill_weights = self.classify(query)

        # 如果所有技能隶属度都很低，默认 RAG
        if max(skill_weights.values()) < 0.1:
            skill_weights["knowledge_rag"] = 0.3

        results = {}
        for skill_name, weight in skill_weights.items():
            if weight > 0.1 and skill_name in self.skills:
                skill = self.skills[skill_name]
                result = skill.execute(query)
                result["skill_weight"] = weight
                results[skill_name] = result

        return {
            "skill_weights": skill_weights,
            "results": results,
        }
