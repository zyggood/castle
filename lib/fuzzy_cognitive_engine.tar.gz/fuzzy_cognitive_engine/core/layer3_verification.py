"""
Layer 3: 模糊验证
比较模型印象和外部证据的匹配程度
"""

from typing import Dict, Any, Optional
from .fuzzy_math import FuzzySet, trimf, centroid


class FuzzyVerifier:
    """模糊验证器"""

    def __init__(self):
        self.similarity_mfs = {
            "strong_match":  lambda x: trimf(x, 0.6, 0.8, 1.0),
            "partial_match": lambda x: trimf(x, 0.3, 0.5, 0.7),
            "mismatch":      lambda x: max(0, min(1, (0.3 - x) / 0.3)) if x < 0.3 else 0,
        }

    def compute_similarity(self, text_a: str, text_b: str) -> float:
        """计算两段文本的语义相似度 (多信号融合)"""
        if not text_a or not text_b:
            return 0.0

        # 方法1: 词汇重叠 (Jaccard) — 基础
        words_a = set(text_a.lower().split())
        words_b = set(text_b.lower().split())
        intersection = words_a & words_b
        union = words_a | words_b
        jaccard = len(intersection) / (len(union) + 1e-10)

        # 方法2: 关键信息匹配
        import re
        numbers_a = set(re.findall(r'\d+\.?\d*', text_a))
        numbers_b = set(re.findall(r'\d+\.?\d*', text_b))
        if numbers_a or numbers_b:
            num_match = len(numbers_a & numbers_b) / (len(numbers_a | numbers_b) + 1e-10)
        else:
            num_match = 0.5  # 没有数字时给中性分

        # 方法3: 长度比 (防止完全无关但大量重复词)
        len_ratio = min(len(text_a), len(text_b)) / (max(len(text_a), len(text_b)) + 1e-10)

        # 方法4: 关键词语义匹配 (同义词/相关词)
        # 提取 3+ 字符的有意义词汇
        meaningful_a = set(w for w in words_a if len(w) >= 3)
        meaningful_b = set(w for w in words_b if len(w) >= 3)
        if meaningful_a and meaningful_b:
            # 子串匹配: "装饰器" 和 "装饰器的设计模式" 匹配
            substring_hits = 0
            for wa in meaningful_a:
                for wb in meaningful_b:
                    if wa in wb or wb in wa:
                        substring_hits += 1
                        break
            substring_score = substring_hits / max(len(meaningful_a), len(meaningful_b))
        else:
            substring_score = 0.0

        # 方法5: 标题/主题匹配 (如果 RAG 结果有【标题】)
        import re
        title_match = 0.0
        titles_b = re.findall(r'【(.+?)】', text_b)
        if titles_b:
            for title in titles_b:
                if title.lower() in text_a.lower() or any(
                    t in text_a.lower() for t in title.lower().split()
                ):
                    title_match = 1.0
                    break

        # 综合相似度 — 加权融合
        similarity = (
            0.20 * jaccard +
            0.15 * num_match +
            0.10 * len_ratio +
            0.35 * substring_score +
            0.20 * title_match
        )
        return min(similarity, 1.0)

    def verify(self, impression: str, external_evidence: Optional[str]) -> Dict[str, Any]:
        """
        验证模型印象和外部证据的匹配度

        Returns:
            {
                "similarity": float,
                "match_profile": {label: degree, ...},
                "source_priority": str,
                "confidence_boost": float,
                "analysis": str,
            }
        """
        if not external_evidence:
            return {
                "similarity": 0.0,
                "match_profile": {"strong_match": 0, "partial_match": 0, "mismatch": 0},
                "source_priority": "impression_only",
                "confidence_boost": 0.0,
                "analysis": "无外部证据可比较",
            }

        # 计算相似度
        similarity = self.compute_similarity(impression, external_evidence)

        # 模糊化
        match_profile = {}
        for label, mf in self.similarity_mfs.items():
            match_profile[label] = round(mf(similarity), 3)

        # 确定来源优先级
        if match_profile["strong_match"] > 0.5:
            source_priority = "both"
            analysis = "模型印象与外部证据强匹配，双重确认"
        elif match_profile["partial_match"] > 0.5:
            source_priority = "evidence_primary"
            analysis = "模型印象与外部证据部分匹配，以外部证据为主"
        elif match_profile["mismatch"] > 0.5:
            source_priority = "evidence_only"
            analysis = "模型印象与外部证据不一致，仅使用外部证据"
        else:
            source_priority = "evidence_primary"
            analysis = "匹配度一般，参考外部证据"

        # 计算置信度提升
        confidence_boost = (
            match_profile["strong_match"] * 0.3 +
            match_profile["partial_match"] * 0.1 +
            match_profile["mismatch"] * (-0.1)
        )

        return {
            "similarity": round(similarity, 4),
            "match_profile": match_profile,
            "source_priority": source_priority,
            "confidence_boost": round(confidence_boost, 4),
            "analysis": analysis,
        }
