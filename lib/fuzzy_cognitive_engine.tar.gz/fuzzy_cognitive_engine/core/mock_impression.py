"""
Mock 模型 (用于无网络环境的演示)
模拟 token 级概率分布，验证模糊推理链路
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict


class MockImpressionGenerator:
    """模拟印象生成器 — 用预设数据模拟模型行为"""

    def __init__(self):
        print("[Mock Layer 0] 初始化模拟模型")
        self.vocab_size = 1000

        # 预设问答对，含不同的不确定性水平
        self.qa_pairs = {
            "python_gil": {
                "question_contains": ["GIL", "gil", "全局解释器锁"],
                "impression": (
                    "GIL (Global Interpreter Lock) 是 Python 解释器中的一个互斥锁，"
                    "它防止多个线程同时执行 Python 字节码。这意味着在 CPython 中，"
                    "即使在多核 CPU 上，同一时刻也只有一个线程能执行 Python 代码。"
                    "GIL 主要影响 CPU 密集型任务的多线程并行性能。"
                    "解决方案包括：使用 multiprocessing 多进程、"
                    "使用 C 扩展释放 GIL、使用 asyncio 处理 I/O 密集型任务。"
                ),
                "confidence": 0.75,  # 中高置信
                "entropy_level": 0.45,
            },
            "factorial": {
                "question_contains": ["阶乘", "factorial"],
                "impression": (
                    "100的阶乘 (100!) 是一个非常大的数，大约等于 "
                    "9.33 × 10^157。这是一个 158 位数。"
                ),
                "confidence": 0.6,  # 中等置信 (精确值不确定)
                "entropy_level": 0.55,
            },
            "decorator": {
                "question_contains": ["装饰器", "decorator"],
                "impression": (
                    "Python 装饰器是一种设计模式，用于在不修改原函数代码的情况下，"
                    "为函数添加额外功能。装饰器本质上是一个接受函数作为参数并返回新函数的高阶函数。"
                    "使用 @decorator 语法糖可以简化调用。常见用途包括日志记录、"
                    "权限检查、缓存、重试机制等。使用 functools.wraps "
                    "可以保留被装饰函数的元数据（如函数名、文档字符串）。"
                ),
                "confidence": 0.82,  # 高置信
                "entropy_level": 0.35,
            },
            "python313": {
                "question_contains": ["3.13", "Python 3.13"],
                "impression": (
                    "Python 3.13 引入了一些新特性，可能包括自由线程模式的实验性支持、"
                    "改进的错误信息、以及一些语法增强。但我不太确定具体细节，"
                    "因为这是较新的版本，我的训练数据中可能覆盖不完整。"
                ),
                "confidence": 0.35,  # 低置信
                "entropy_level": 0.72,
            },
            "generator": {
                "question_contains": ["生成器", "generator", "yield"],
                "impression": (
                    "Python 生成器是使用 yield 关键字的特殊函数，返回一个迭代器对象。"
                    "生成器的核心特点是惰性求值——每次调用 next() 时才计算下一个值，"
                    "因此在处理大数据集时可以显著节省内存。"
                    "生成器函数中可以使用 yield 产出值，使用 send() 传入值，"
                    "使用 throw() 抛出异常。itertools 模块提供了丰富的迭代器工具。"
                ),
                "confidence": 0.85,
                "entropy_level": 0.30,
            },
            "generic": {
                "question_contains": [],
                "impression": (
                    "这是一个关于编程的问题。我大致了解相关内容，"
                    "但具体的细节我不太确定，建议查阅权威文档获取准确信息。"
                ),
                "confidence": 0.30,
                "entropy_level": 0.70,
            },
        }

    def _match_question(self, question: str) -> dict:
        """匹配问题到预设 QA 对"""
        question_lower = question.lower()

        best_match = None
        best_score = 0

        for key, qa in self.qa_pairs.items():
            if key == "generic":
                continue
            score = sum(1 for kw in qa["question_contains"] if kw.lower() in question_lower)
            if score > best_score:
                best_score = score
                best_match = qa

        if best_match is None or best_score == 0:
            return self.qa_pairs["generic"]
        return best_match

    def _generate_logits(self, text: str, entropy_level: float) -> torch.Tensor:
        """根据文本和熵水平生成模拟 logits"""
        tokens = text.split()  # 简化分词
        n_tokens = min(len(tokens), 80)

        logits_list = []
        for i in range(n_tokens):
            # 模拟 logits 分布
            base_logits = torch.randn(self.vocab_size) * 0.5

            # 添加"确定性"的尖峰
            peak_idx = hash(tokens[i % len(tokens)]) % self.vocab_size
            peak_strength = (1.0 - entropy_level) * 5.0
            base_logits[peak_idx] += peak_strength

            # 添加一些噪声
            noise = torch.randn(self.vocab_size) * entropy_level * 2.0
            base_logits += noise

            logits_list.append(base_logits)

        return torch.stack(logits_list)

    def generate_impression(self, question: str, max_new_tokens: int = 200) -> Dict:
        """生成模拟印象"""
        qa = self._match_question(question)
        impression = qa["impression"]
        logits = self._generate_logits(impression, qa["entropy_level"])

        return {
            "question": question,
            "impression": impression,
            "logits": logits,
            "generated_ids": torch.zeros(logits.shape[0], dtype=torch.long),
            "n_tokens": logits.shape[0],
        }

    def generate_multiple(self, question: str, n_samples: int = 3,
                          max_new_tokens: int = 150, temperature: float = 0.7) -> list:
        """多次采样生成 (模拟)"""
        qa = self._match_question(question)
        base = qa["impression"]
        results = [base]

        # 生成变体
        variations = [
            base.replace("是", "应该是指").replace("的", " 的 "),
            base[:len(base)//2] + "。具体细节建议查阅官方文档。",
            base,
        ]
        for i in range(n_samples - 1):
            results.append(variations[i % len(variations)])

        return results[:n_samples]
