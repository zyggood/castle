"""
模糊认知引擎 - 主引擎
串联 Layer 0-4，完成完整的推理流程
"""

import time
import sys
import os
from typing import Dict, Any, Optional

# 确保包路径正确
_pkg_dir = os.path.dirname(os.path.abspath(__file__))
if _pkg_dir not in sys.path:
    sys.path.insert(0, _pkg_dir)

from core.layer0_impression import ImpressionGenerator
from core.layer1_uncertainty import UncertaintyAssessor
from core.layer2_router import FuzzySkillRouter
from core.layer3_verification import FuzzyVerifier
from core.layer4_fusion import FuzzyFusionOutput
from skills.rag_skill import RAGSkill
from skills.code_skill import CodeSkill


class FuzzyCognitiveEngine:
    """模糊认知引擎"""

    def __init__(self, model_name: str = None,
                 use_mock: bool = True,
                 use_self_consistency: bool = True, n_consistency_samples: int = 3):
        """
        Args:
            model_name: HuggingFace 模型名 (use_mock=False 时使用)
            use_mock: 使用模拟模型 (无网络环境)
            use_self_consistency: 是否启用自一致性检测
            n_consistency_samples: 自一致性采样次数
        """
        self.use_self_consistency = use_self_consistency
        self.n_samples = n_consistency_samples

        print("=" * 60)
        print("🧠 模糊认知引擎初始化")
        print("=" * 60)

        # Layer 0: 印象生成器
        if use_mock:
            from core.mock_impression import MockImpressionGenerator
            self.impression_gen = MockImpressionGenerator()
        else:
            self.impression_gen = ImpressionGenerator(model_name)

        # Layer 1: 不确定性评估器
        self.uncertainty_assessor = UncertaintyAssessor()

        # Layer 2: 技能路由器
        self.skills = {
            "knowledge_rag": RAGSkill(),
            "code_exec": CodeSkill(timeout=15),
        }
        self.router = FuzzySkillRouter(self.skills)

        # Layer 3: 验证器
        self.verifier = FuzzyVerifier()

        # Layer 4: 融合输出
        self.fusion = FuzzyFusionOutput()

        print("✅ 所有层初始化完成")
        print(f"   自一致性检测: {'开启' if use_self_consistency else '关闭'} "
              f"({n_consistency_samples} 次采样)")
        print(f"   可用技能: {list(self.skills.keys())}")
        print("=" * 60)

    def think(self, question: str, verbose: bool = True) -> Dict[str, Any]:
        """
        主推理流程

        Args:
            question: 用户问题
            verbose: 是否打印中间过程

        Returns:
            完整的推理结果
        """
        start_time = time.time()
        result = {"question": question, "layers": {}}

        if verbose:
            print(f"\n{'='*60}")
            print(f"📝 问题: {question}")
            print(f"{'='*60}")

        # ========================================================
        # Layer 0: 生成印象
        # ========================================================
        if verbose:
            print("\n🔵 [Layer 0] 生成模型印象...")

        impression_data = self.impression_gen.generate_impression(question)
        result["layers"]["layer0"] = {
            "impression": impression_data["impression"],
            "n_tokens": impression_data["n_tokens"],
        }

        if verbose:
            print(f"   印象: {impression_data['impression'][:100]}...")
            print(f"   Token 数: {impression_data['n_tokens']}")

        # ========================================================
        # Layer 1: 不确定性评估
        # ========================================================
        if verbose:
            print("\n🟡 [Layer 1] 模糊不确定性评估...")

        # 自一致性检测 (可选)
        self_consistency = None
        if self.use_self_consistency:
            if verbose:
                print(f"   执行自一致性检测 ({self.n_samples} 次采样)...")
            responses = self.impression_gen.generate_multiple(
                question, n_samples=self.n_samples
            )
            self_consistency = self.uncertainty_assessor.compute_self_consistency(responses)
            if verbose:
                print(f"   自一致性: {self_consistency:.3f}")
                for i, r in enumerate(responses):
                    print(f"     样本{i+1}: {r[:60]}...")

        uncertainty = self.uncertainty_assessor.assess(
            logits=impression_data["logits"],
            impression=impression_data["impression"],
            self_consistency=self_consistency,
        )
        result["layers"]["layer1"] = uncertainty

        if verbose:
            print(f"   置信度: {uncertainty['fused_confidence']:.4f}")
            print(f"   置信标签: {uncertainty['confidence_label']}")
            print(f"   不确定性画像: {uncertainty['uncertainty_profile']}")
            print(f"   是否查询外部: {'是' if uncertainty['should_query'] else '否'}")

        # ========================================================
        # 如果置信度足够高，直接输出
        # ========================================================
        if not uncertainty["should_query"]:
            if verbose:
                print("\n✅ 置信度足够高，直接输出印象")

            final = {
                "answer": impression_data["impression"],
                "confidence": uncertainty["fused_confidence"],
                "confidence_label": uncertainty["confidence_label"],
                "source": "模型印象 (高置信)",
                "note": "💡 模型对答案较为确定，无需外部验证",
                "elapsed": round(time.time() - start_time, 2),
            }
            result["final"] = final
            self._print_result(final, verbose)
            return result

        # ========================================================
        # Layer 2: 模糊技能路由
        # ========================================================
        if verbose:
            print("\n🟢 [Layer 2] 模糊技能路由...")

        route_result = self.router.route(question, uncertainty["uncertainty_profile"])
        result["layers"]["layer2"] = {
            "skill_weights": route_result["skill_weights"],
        }

        if verbose:
            print(f"   技能权重: {route_result['skill_weights']}")
            for skill_name, skill_result in route_result["results"].items():
                found = skill_result.get("found", skill_result.get("answer") is not None)
                print(f"   {skill_name}: {'✅ 找到' if found else '❌ 未找到'} "
                      f"(相关性: {skill_result.get('relevance', 0):.2f})")

        # === 代码生成: code_exec 识别了计算任务但没有现成代码 ===
        code_skill = self.skills.get("code_exec")
        if code_skill:
            for skill_name, skill_result in route_result["results"].items():
                if skill_result.get("needs_code_generation"):
                    if verbose:
                        print(f"\n   🔧 检测到计算任务，自动生成代码...")
                    generated_code = self._generate_code_for_question(question)
                    if generated_code:
                        exec_result = code_skill.generate_and_run(generated_code)
                        exec_result["skill_weight"] = skill_result.get("skill_weight", 0.5)
                        exec_result["relevance"] = 0.9  # 代码执行结果高相关
                        exec_result["found"] = True
                        exec_result["auto_generated_code"] = True
                        route_result["results"][skill_name] = exec_result
                        if verbose:
                            print(f"   生成代码:\n```python\n{generated_code}\n```")
                            print(f"   执行结果: {exec_result.get('answer', 'N/A')[:100]}")

        # ========================================================
        # Layer 3: 模糊验证
        # ========================================================
        if verbose:
            print("\n🟠 [Layer 3] 模糊验证...")

        # 获取最佳外部证据
        best_evidence = None
        for skill_name, skill_result in route_result["results"].items():
            if skill_result.get("answer") and skill_result.get("relevance", 0) > 0:
                best_evidence = skill_result["answer"]
                break

        verification = self.verifier.verify(
            impression=impression_data["impression"],
            external_evidence=best_evidence,
        )
        result["layers"]["layer3"] = verification

        if verbose:
            print(f"   语义相似度: {verification['similarity']:.4f}")
            print(f"   匹配画像: {verification['match_profile']}")
            print(f"   来源优先级: {verification['source_priority']}")
            print(f"   分析: {verification['analysis']}")

        # ========================================================
        # Layer 4: 模糊融合输出
        # ========================================================
        if verbose:
            print("\n🔴 [Layer 4] 模糊融合输出...")

        final = self.fusion.fuse(
            impression=impression_data["impression"],
            impression_confidence=uncertainty["fused_confidence"],
            external_results=route_result,
            verification=verification,
        )
        final["elapsed"] = round(time.time() - start_time, 2)
        result["final"] = final

        self._print_result(final, verbose)
        return result

    def _generate_code_for_question(self, question: str) -> str:
        """根据问题生成 Python 代码"""
        import re

        q = question.lower()

        # 阶乘
        if "阶乘" in q or "factorial" in q:
            nums = re.findall(r'\d+', question)
            n = nums[0] if nums else "10"
            return f"import math\nprint(f'{n}! = {{math.factorial({n})}}')\nprint(f'位数: {{len(str(math.factorial({n})))}}')"

        # 斐波那契
        if "斐波那契" in q or "fibonacci" in q:
            nums = re.findall(r'\d+', question)
            n = nums[0] if nums else "20"
            return f"""def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

for i in range({n}):
    print(f"fib({{i}}) = {{fib(i)}}")"""

        # 平方根 / sqrt
        if "平方" in q or "sqrt" in q:
            nums = re.findall(r'\d+\.?\d*', question)
            n = nums[0] if nums else "2"
            return f"import math\nprint(f'sqrt({n}) = {{math.sqrt({n})}}')"

        # 素数
        if "素数" in q or "质数" in q or "prime" in q:
            nums = re.findall(r'\d+', question)
            n = nums[0] if nums else "100"
            return f"""def is_prime(n):
    if n < 2: return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0: return False
    return True

primes = [x for x in range(2, {n}+1) if is_prime(x)]
print(f"2到{n}之间的素数: {{primes}}")
print(f"共 {{len(primes)}} 个")"""

        # 排序
        if "排序" in q or "sort" in q:
            return """import random
import time

data = [random.randint(1, 1000) for _ in range(1000)]

# 各种排序
for name, func in [
    ("sorted()", sorted),
    ("list.sort()", lambda x: x.copy().sort() or x),
]:
    start = time.time()
    result = func(data)
    print(f"{name}: {time.time()-start:.6f}s")"""

        # 通用数学表达式
        math_patterns = re.findall(r'(\d+)\s*[\+\-\*\/\%\^]\s*(\d+)', question)
        if math_patterns:
            # 提取看起来像表达式的部分
            expr_candidates = re.findall(r'[\d\+\-\*\/\%\^\(\)\.\s]+', question)
            expr_candidates = [e.strip() for e in expr_candidates if any(op in e for op in '+-*/%^')]
            if expr_candidates:
                expr = expr_candidates[0].replace('^', '**')
                return f"result = {expr}\nprint(f'{expr} = {{result}}')"

        return ""

    def _print_result(self, final: Dict, verbose: bool):
        """打印最终结果"""
        if not verbose:
            return

        elapsed = final.get("elapsed", 0)
        print(f"\n{'='*60}")
        print(f"🎯 最终结果 (耗时 {elapsed:.1f}s)")
        print(f"{'='*60}")
        print(f"📝 答案: {final['answer'][:200]}")
        if len(final.get("answer", "")) > 200:
            print(f"   ... (共 {len(final['answer'])} 字符)")
        print(f"📊 置信度: {final['confidence']:.4f} ({final['confidence_label']})")
        print(f"📌 来源: {final['source']}")
        print(f"💬 备注: {final['note']}")
        print(f"{'='*60}")
