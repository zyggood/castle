"""
模糊认知引擎 - 演示脚本
"""

import sys
import os

# 添加项目根目录到 path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine import FuzzyCognitiveEngine


def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║              🧠 模糊认知引擎 - Fuzzy Cognitive Engine         ║
║                                                              ║
║  能力与知识分离，用模糊推理管理不确定性的智能问答系统           ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # 初始化引擎 (使用 mock 模型，无需网络)
    engine = FuzzyCognitiveEngine(
        use_mock=True,
        use_self_consistency=True,
        n_consistency_samples=3,
    )

    # 测试用例: 覆盖不同场景
    test_cases = [
        # 1. 知识型问题 (应该触发 RAG)
        "Python 的 GIL 是什么？它如何影响多线程性能？",

        # 2. 计算型问题 (应该触发代码执行)
        "计算 100 的阶乘",

        # 3. 模型可能不确定的问题
        "Python 3.13 有什么新特性？",

        # 4. 代码实现问题
        "用 Python 实现一个装饰器，统计函数执行时间",
    ]

    for i, question in enumerate(test_cases, 1):
        print(f"\n\n{'#'*60}")
        print(f"# 测试 {i}/{len(test_cases)}")
        print(f"{'#'*60}")

        result = engine.think(question, verbose=True)

        # 保存结果
        print(f"\n📋 详细信号:")
        if "layers" in result:
            for layer_name, layer_data in result["layers"].items():
                if isinstance(layer_data, dict):
                    for k, v in layer_data.items():
                        print(f"   {layer_name}.{k}: {v}")

    # 交互模式
    print(f"\n\n{'='*60}")
    print("💬 交互模式 (输入问题，输入 'quit' 退出)")
    print(f"{'='*60}")

    while True:
        try:
            question = input("\n你的问题: ").strip()
            if question.lower() in ('quit', 'exit', 'q', '退出'):
                print("👋 再见!")
                break
            if not question:
                continue

            result = engine.think(question, verbose=True)
        except KeyboardInterrupt:
            print("\n👋 再见!")
            break
        except EOFError:
            break


if __name__ == "__main__":
    main()
