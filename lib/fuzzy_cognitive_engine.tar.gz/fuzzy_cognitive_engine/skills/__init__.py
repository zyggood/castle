# Fuzzy Cognitive Engine - Skills
