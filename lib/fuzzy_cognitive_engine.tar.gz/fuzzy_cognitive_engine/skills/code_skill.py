"""
代码执行技能
安全沙箱内执行 Python 代码
"""

import subprocess
import sys
import tempfile
import os
import signal
from typing import Dict, Any
from .base_skill import BaseSkill


class CodeSkill(BaseSkill):
    """Python 代码执行"""

    @property
    def name(self) -> str:
        return "code_exec"

    @property
    def description(self) -> str:
        return "在安全沙箱中执行 Python 代码，适合数学计算和复杂逻辑"

    def __init__(self, timeout: int = 10):
        self.timeout = timeout

    def execute(self, query: str) -> Dict[str, Any]:
        """
        从查询中提取或生成 Python 代码并执行
        """
        # 如果查询本身包含代码，提取执行
        code = self._extract_code(query)

        if code:
            return self._run_code(code)

        # 否则返回提示让引擎生成代码
        return {
            "answer": None,
            "source": "code_exec",
            "relevance": 0.0,
            "needs_code_generation": True,
            "raw": query,
        }

    def _extract_code(self, text: str) -> str:
        """从文本中提取 Python 代码"""
        # 检查 ```python ... ``` 代码块
        import re
        blocks = re.findall(r'```python\s*\n(.*?)```', text, re.DOTALL)
        if blocks:
            return blocks[0].strip()

        # 检查 ``` ... ``` 代码块
        blocks = re.findall(r'```\s*\n(.*?)```', text, re.DOTALL)
        if blocks:
            return blocks[0].strip()

        # 检查是否直接是代码
        lines = text.strip().split('\n')
        code_indicators = ['import ', 'def ', 'class ', 'print(', 'for ', 'if ',
                           'return ', '=', '[]', '{}', 'lambda']
        if any(ind in text for ind in code_indicators):
            return text.strip()

        return ""

    def _run_code(self, code: str) -> Dict[str, Any]:
        """在沙箱中执行代码"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_file = f.name

        try:
            result = subprocess.run(
                [sys.executable, temp_file],
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=tempfile.gettempdir(),
            )

            if result.returncode == 0:
                output = result.stdout.strip()
                return {
                    "answer": f"代码执行结果:\n```\n{output}\n```" if output else "代码执行成功，无输出",
                    "source": "code_exec",
                    "relevance": 1.0,
                    "code": code,
                    "output": output,
                    "error": None,
                    "raw": {"stdout": output, "stderr": result.stderr},
                }
            else:
                return {
                    "answer": f"代码执行出错:\n```\n{result.stderr}\n```",
                    "source": "code_exec",
                    "relevance": 0.5,
                    "code": code,
                    "output": result.stdout,
                    "error": result.stderr,
                    "raw": {"stdout": result.stdout, "stderr": result.stderr},
                }

        except subprocess.TimeoutExpired:
            return {
                "answer": f"代码执行超时 ({self.timeout}秒)",
                "source": "code_exec",
                "relevance": 0.0,
                "code": code,
                "error": "Timeout",
                "raw": {},
            }
        except Exception as e:
            return {
                "answer": f"代码执行异常: {str(e)}",
                "source": "code_exec",
                "relevance": 0.0,
                "code": code,
                "error": str(e),
                "raw": {},
            }
        finally:
            os.unlink(temp_file)

    def generate_and_run(self, code: str) -> Dict[str, Any]:
        """直接执行给定的代码"""
        return self._run_code(code)
