"""
RAG 知识检索技能
基于关键词匹配的轻量级知识库 (无需 FAISS，可后续替换为向量检索)
"""

import re
from typing import Dict, Any, List
from .base_skill import BaseSkill


class RAGSkill(BaseSkill):
    """编程领域知识检索"""

    @property
    def name(self) -> str:
        return "knowledge_rag"

    @property
    def description(self) -> str:
        return "从编程知识库中检索相关信息"

    def __init__(self):
        self.knowledge_base = self._build_kb()

    def _build_kb(self) -> List[Dict]:
        """构建编程领域知识库"""
        return [
            {
                "topic": "Python 列表推导式",
                "keywords": ["列表推导", "list comprehension", "列表生成", "推导式"],
                "content": "列表推导式是 Python 中创建列表的简洁语法: [expr for item in iterable if condition]。"
                           "例如 [x**2 for x in range(10) if x % 2 == 0] 生成 0-9 中偶数的平方。"
                           "性能通常优于等价的 for 循环 + append，但过于复杂的推导式会降低可读性。",
                "example": "squares = [x**2 for x in range(10) if x % 2 == 0]",
            },
            {
                "topic": "Python GIL",
                "keywords": ["GIL", "全局解释器锁", "Global Interpreter Lock", "多线程", "线程安全"],
                "content": "GIL (Global Interpreter Lock) 是 CPython 的一个互斥锁，确保同一时间只有一个线程执行 Python 字节码。"
                           "这意味着 CPU 密集型的多线程 Python 程序无法利用多核 CPU 并行执行。"
                           "解决方案: multiprocessing (多进程)、C 扩展释放 GIL、asyncio (I/O 密集型)、"
                           "Python 3.13+ 的 free-threaded 模式 (实验性)。",
                "example": "from multiprocessing import Pool\nwith Pool(4) as p:\n    results = p.map(func, data)",
            },
            {
                "topic": "Python 装饰器",
                "keywords": ["装饰器", "decorator", "@语法糖", "函数包装"],
                "content": "装饰器是 Python 中修改函数/类行为的设计模式。本质上是一个接受函数并返回函数的高阶函数。"
                           "用 @decorator 语法糖简化调用。常见用途: 日志、权限检查、缓存、重试。"
                           "functools.wraps 保留被装饰函数的元数据。",
                "example": "import functools\n\ndef timer(func):\n    @functools.wraps(func)\n    def wrapper(*args, **kwargs):\n        start = time.time()\n        result = func(*args, **kwargs)\n        print(f'{func.__name__}: {time.time()-start:.2f}s')\n        return result\n    return wrapper",
            },
            {
                "topic": "Python 生成器与迭代器",
                "keywords": ["生成器", "generator", "yield", "迭代器", "iterator", "惰性求值"],
                "content": "生成器是使用 yield 关键字的函数，返回一个迭代器对象。"
                           "惰性求值: 每次 next() 才计算下一个值，节省内存。"
                           "适合处理大数据流、无限序列。send() 可以向生成器传值。"
                           "itertools 模块提供常用迭代器工具。",
                "example": "def fibonacci():\n    a, b = 0, 1\n    while True:\n        yield a\n        a, b = b, a + b",
            },
            {
                "topic": "Python 类型注解",
                "keywords": ["类型注解", "type hint", "typing", "类型检查", "mypy", "annotation"],
                "content": "Python 3.5+ 支持类型注解 (PEP 484)，用 : type 标注参数，-> type 标注返回值。"
                           "typing 模块提供 List, Dict, Optional, Union, Generic 等类型。"
                           "Python 3.10+ 支持 | 语法代替 Union (int | str)。"
                           "类型注解不强制执行，需要 mypy/pyright 等工具检查。",
                "example": "from typing import Optional\n\ndef greet(name: str, greeting: Optional[str] = None) -> str:\n    return f'{greeting or \"Hello\"}, {name}!'",
            },
            {
                "topic": "Python 异步编程",
                "keywords": ["异步", "async", "await", "asyncio", "协程", "coroutine", "事件循环"],
                "content": "Python 3.5+ 的 async/await 语法支持异步编程。"
                           "asyncio 是标准库的事件循环实现。协程函数用 async def 定义，用 await 调用。"
                           "适合 I/O 密集型任务（网络请求、文件操作），不适合 CPU 密集型。"
                           "常用: asyncio.gather() 并发执行, asyncio.create_task() 创建任务。",
                "example": "import asyncio\n\nasync def fetch(url):\n    async with aiohttp.ClientSession() as s:\n        async with s.get(url) as r:\n            return await r.text()\n\nresults = await asyncio.gather(fetch(url1), fetch(url2))",
            },
            {
                "topic": "Python 上下文管理器",
                "keywords": ["上下文管理器", "with", "__enter__", "__exit__", "contextmanager"],
                "content": "上下文管理器通过 with 语句管理资源的获取和释放。"
                           "实现方式: 类实现 __enter__/__exit__ 方法，或用 contextlib.contextmanager 装饰器。"
                           "常见用途: 文件操作、数据库连接、锁、临时修改配置。",
                "example": "from contextlib import contextmanager\n\n@contextmanager\ndef timer():\n    start = time.time()\n    yield\n    print(f'Elapsed: {time.time()-start:.2f}s')",
            },
            {
                "topic": "Python 数据结构选择",
                "keywords": ["数据结构", "list", "dict", "set", "tuple", "deque", "性能", "选择"],
                "content": "Python 内置数据结构复杂度:\n"
                           "- list: 有序, O(1) append/pop, O(n) insert/search\n"
                           "- dict: 哈希表, O(1) 平均查找/插入\n"
                           "- set: 哈希集合, O(1) 平均成员检测\n"
                           "- tuple: 不可变 list, 可做 dict key\n"
                           "- collections.deque: 双端队列, O(1) 两端操作\n"
                           "- heapq: 堆, O(log n) 插入, O(1) 查看最小值",
                "example": "from collections import deque\nqueue = deque(maxlen=1000)  # 固定大小队列\nqueue.append(item)\nqueue.popleft()",
            },
            {
                "topic": "Python 内存管理",
                "keywords": ["内存", "memory", "垃圾回收", "gc", "引用计数", "内存泄漏", "弱引用"],
                "content": "Python 内存管理机制:\n"
                           "1. 引用计数: 每个对象维护引用计数，归零时立即释放\n"
                           "2. 标记-清除: 处理循环引用\n"
                           "3. 分代回收: 对象分为 3 代，年轻代更频繁回收\n"
                           "常见内存泄漏: 全局变量引用、闭包捕获、__del__ 方法。"
                           "gc 模块可手动控制垃圾回收。weakref 模块提供弱引用。",
                "example": "import gc\nimport weakref\n\nclass Cache:\n    def __init__(self):\n        self._data = {}\n    def set(self, key, obj):\n        self._data[key] = weakref.ref(obj)",
            },
            {
                "topic": "Python 设计模式",
                "keywords": ["设计模式", "单例", "singleton", "工厂", "factory", "观察者", "observer", "策略", "strategy"],
                "content": "常用设计模式的 Python 实现:\n"
                           "- 单例: 用模块级变量或 __new__ 控制\n"
                           "- 工厂: 用字典映射类型到类\n"
                           "- 观察者: 用回调列表或事件系统\n"
                           "- 策略: 函数是一等公民，直接传函数即可\n"
                           "Python 的灵活性让很多模式变得简单甚至不必要。",
                "example": "# Python 风格的策略模式\ndef sort_by(data, key_func):\n    return sorted(data, key=key_func)\n\nsort_by(users, key_func=lambda u: u.age)",
            },
            {
                "topic": "排序算法复杂度",
                "keywords": ["排序", "sort", "快速排序", "归并排序", "复杂度", "时间复杂度", "算法"],
                "content": "常见排序算法:\n"
                           "- 冒泡排序: O(n²), 稳定\n"
                           "- 选择排序: O(n²), 不稳定\n"
                           "- 插入排序: O(n²), 稳定, 对近乎有序的数据 O(n)\n"
                           "- 快速排序: O(n log n) 平均, O(n²) 最坏, 不稳定\n"
                           "- 归并排序: O(n log n), 稳定, 需要 O(n) 额外空间\n"
                           "- 堆排序: O(n log n), 不稳定, 原地\n"
                           "Python 的 sorted() 使用 Timsort (归并+插入), O(n log n), 稳定。",
                "example": "# Python sorted() 使用 Timsort\nsorted_data = sorted(data, key=lambda x: x['score'], reverse=True)",
            },
            {
                "topic": "HTTP 状态码",
                "keywords": ["HTTP", "状态码", "status code", "200", "404", "500", "REST", "API"],
                "content": "HTTP 状态码分类:\n"
                           "1xx: 信息性 (100 Continue)\n"
                           "2xx: 成功 (200 OK, 201 Created, 204 No Content)\n"
                           "3xx: 重定向 (301 Moved Permanently, 304 Not Modified)\n"
                           "4xx: 客户端错误 (400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found)\n"
                           "5xx: 服务器错误 (500 Internal Server Error, 502 Bad Gateway, 503 Service Unavailable)",
                "example": "# FastAPI 中返回不同状态码\nfrom fastapi import HTTPException\nraise HTTPException(status_code=404, detail='Not found')",
            },
            {
                "topic": "Python 正则表达式",
                "keywords": ["正则", "regex", "re模块", "正则表达式", "模式匹配", "正则匹配"],
                "content": "re 模块提供正则表达式支持:\n"
                           "- re.match(): 从字符串开头匹配\n"
                           "- re.search(): 扫描整个字符串找第一个匹配\n"
                           "- re.findall(): 返回所有匹配\n"
                           "- re.sub(): 替换\n"
                           "常用: \\d 数字, \\w 字母数字, \\s 空白, . 任意字符, * 0+, + 1+, ? 0或1\n"
                           "使用 raw string (r'...') 避免转义问题。",
                "example": "import re\nemails = re.findall(r'[\\w.]+@[\\w]+\\.[a-z]{2,}', text)",
            },
            {
                "topic": "Python 虚拟环境",
                "keywords": ["虚拟环境", "venv", "virtualenv", "pip", "依赖管理", "requirements", "环境"],
                "content": "Python 虚拟环境隔离项目依赖:\n"
                           "创建: python -m venv .venv\n"
                           "激活: source .venv/bin/activate (Linux/Mac), .venv\\Scripts\\activate (Windows)\n"
                           "导出: pip freeze > requirements.txt\n"
                           "安装: pip install -r requirements.txt\n"
                           "Python 3.11+ 推荐用 pipx 安装全局工具。"
                           "现代项目推荐使用 pyproject.toml + poetry/uv。",
                "example": "python -m venv .venv\nsource .venv/bin/activate\npip install requests flask",
            },
        ]

    def execute(self, query: str) -> Dict[str, Any]:
        """基于关键词匹配检索知识库"""
        query_lower = query.lower()
        scored = []

        for entry in self.knowledge_base:
            score = 0
            for kw in entry["keywords"]:
                if kw.lower() in query_lower:
                    score += 2
                # 部分匹配
                elif any(kw_c in query_lower for kw_c in kw.lower().split()):
                    score += 0.5

            if score > 0:
                scored.append((score, entry))

        if not scored:
            # 没有找到匹配
            return {
                "answer": None,
                "source": "knowledge_rag",
                "relevance": 0.0,
                "raw": [],
                "found": False,
            }

        # 按分数排序
        scored.sort(key=lambda x: x[0], reverse=True)
        best_score, best_entry = scored[0]

        # 归一化相关性
        relevance = min(best_score / 6.0, 1.0)  # 最高 6 分 (3 个关键词全中)

        # 组装答案
        answer = f"【{best_entry['topic']}】\n{best_entry['content']}"
        if "example" in best_entry:
            answer += f"\n\n示例:\n```python\n{best_entry['example']}\n```"

        return {
            "answer": answer,
            "source": "knowledge_rag",
            "relevance": round(relevance, 3),
            "topic": best_entry["topic"],
            "raw": [e[1] for e in scored[:3]],
            "found": True,
        }
