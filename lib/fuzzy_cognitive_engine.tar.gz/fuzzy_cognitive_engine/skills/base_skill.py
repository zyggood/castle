"""
技能基类
所有技能继承此基类
"""

from abc import ABC, abstractmethod
from typing import Dict, Any


class BaseSkill(ABC):
    """技能基类"""

    @property
    @abstractmethod
    def name(self) -> str:
        """技能名称"""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """技能描述"""
        pass

    @abstractmethod
    def execute(self, query: str) -> Dict[str, Any]:
        """
        执行技能
        返回: {
            "answer": str,
            "source": str,
            "relevance": float,  # 0-1
            "raw": Any           # 原始数据
        }
        """
        pass
