"""
买卖时机信号系统
多维度信号融合，给出明确的买入/卖出建议
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pandas as pd
import numpy as np
from analysis.technical import (calc_ma, calc_macd, calc_kdj, calc_rsi, calc_boll,
                                 macd_signal_detect, kdj_signal, rsi_signal,
                                 boll_signal, ma_trend, volume_analysis)
from data.fetcher import get_stock_daily


class TimingSignal:
    """买卖时机信号"""

    BUY_SIGNALS = {
        "macd_golden": ("MACD金叉", 25),
        "kdj_golden_low": ("KDJ低位金叉", 25),
        "rsi_oversold": ("RSI超卖", 20),
        "boll_lower": ("触及布林下轨", 20),
        "ma_golden": ("均线金叉", 18),
        "volume_surge_up": ("放量上涨", 15),
        "break_resistance": ("突破阻力位", 20),
        "double_bottom": ("W底形态", 22),
        "bullish_engulfing": ("阳包阴形态", 18),
    }

    SELL_SIGNALS = {
        "macd_death": ("MACD死叉", -25),
        "kdj_death_high": ("KDJ高位死叉", -25),
        "rsi_overbought": ("RSI超买", -20),
        "boll_upper": ("触及布林上轨", -20),
        "ma_death": ("均线死叉", -18),
        "volume_surge_down": ("放量下跌", -20),
        "break_support": ("跌破支撑位", -22),
        "double_top": ("M头形态", -22),
        "bearish_engulfing": ("阴包阳形态", -18),
    }


def detect_signals(df: pd.DataFrame) -> dict:
    """
    检测所有买卖信号
    返回: { buy_signals: [...], sell_signals: [...], total: int, recommendation: str }
    """
    if len(df) < 60:
        return {"error": "数据不足", "buy_signals": [], "sell_signals": []}

    df = calc_ma(df)
    df = calc_macd(df)
    df = calc_kdj(df)
    df = calc_rsi(df)
    df = calc_boll(df)

    buy_signals = []
    sell_signals = []
    buy_score = 0
    sell_score = 0

    latest = df.iloc[-1]
    prev = df.iloc[-2]

    # ========== MACD 信号 ==========
    if prev["DIF"] < prev["DEA"] and latest["DIF"] > latest["DEA"]:
        buy_signals.append(("MACD金叉⭐", 25))
        buy_score += 25
    elif prev["DIF"] > prev["DEA"] and latest["DIF"] < latest["DEA"]:
        sell_signals.append(("MACD死叉⚠️", -25))
        sell_score += 25

    # MACD柱状线由负转正
    if prev["MACD"] < 0 and latest["MACD"] > 0:
        buy_signals.append(("MACD柱转正", 15))
        buy_score += 15
    elif prev["MACD"] > 0 and latest["MACD"] < 0:
        sell_signals.append(("MACD柱转负", -15))
        sell_score += 15

    # ========== KDJ 信号 ==========
    if prev["K"] < prev["D"] and latest["K"] > latest["D"]:
        if latest["K"] < 30:
            buy_signals.append(("KDJ低位金叉⭐", 25))
            buy_score += 25
        else:
            buy_signals.append(("KDJ金叉", 15))
            buy_score += 15
    elif prev["K"] > prev["D"] and latest["K"] < latest["D"]:
        if latest["K"] > 70:
            sell_signals.append(("KDJ高位死叉⚠️", -25))
            sell_score += 25
        else:
            sell_signals.append(("KDJ死叉", -15))
            sell_score += 15

    if latest["J"] < 0:
        buy_signals.append(("J值超卖", 10))
        buy_score += 10
    elif latest["J"] > 100:
        sell_signals.append(("J值超买", -10))
        sell_score += 10

    # ========== RSI 信号 ==========
    if latest["RSI"] < 30:
        buy_signals.append(("RSI超卖区⭐", 20))
        buy_score += 20
    elif latest["RSI"] > 70:
        sell_signals.append(("RSI超买区⚠️", -20))
        sell_score += 20

    # ========== 布林带信号 ==========
    if latest["收盘"] <= latest["BOLL_LOW"]:
        buy_signals.append(("触及布林下轨", 20))
        buy_score += 20
    elif latest["收盘"] >= latest["BOLL_UP"]:
        sell_signals.append(("触及布林上轨", -20))
        sell_score += 20

    # ========== 均线信号 ==========
    if prev["MA5"] < prev["MA20"] and latest["MA5"] > latest["MA20"]:
        buy_signals.append(("MA5上穿MA20", 18))
        buy_score += 18
    elif prev["MA5"] > prev["MA20"] and latest["MA5"] < latest["MA20"]:
        sell_signals.append(("MA5下穿MA20", -18))
        sell_score += 18

    # 均线多头/空头排列
    if latest["MA5"] > latest["MA10"] > latest["MA20"] > latest["MA60"]:
        buy_signals.append(("均线多头排列", 15))
        buy_score += 15
    elif latest["MA5"] < latest["MA10"] < latest["MA20"] < latest["MA60"]:
        sell_signals.append(("均线空头排列", -15))
        sell_score += 15

    # ========== 量价信号 ==========
    vol = latest["成交量"]
    vol_ma5 = df["成交量"].rolling(5).mean().iloc[-1]
    vol_ratio = vol / (vol_ma5 + 1e-10)

    if vol_ratio > 2.0 and latest["涨跌幅"] > 3:
        buy_signals.append(("放量上涨📈", 18))
        buy_score += 18
    elif vol_ratio > 2.0 and latest["涨跌幅"] < -3:
        sell_signals.append(("放量下跌📉", -20))
        sell_score += 20

    # 缩量回调（健康回调信号）
    if vol_ratio < 0.6 and -3 < latest["涨跌幅"] < 0 and latest["收盘"] > latest["MA20"]:
        buy_signals.append(("缩量回调（健康）", 10))
        buy_score += 10

    # ========== K线形态 ==========
    # 阳包阴
    if (prev["收盘"] < prev["开盘"] and  # 前日阴线
        latest["收盘"] > latest["开盘"] and  # 今日阳线
        latest["收盘"] > prev["开盘"] and  # 收盘高于前日开盘
        latest["开盘"] < prev["收盘"]):  # 开盘低于前日收盘
        buy_signals.append(("阳包阴形态⭐", 18))
        buy_score += 18

    # 阴包阳
    if (prev["收盘"] > prev["开盘"] and
        latest["收盘"] < latest["开盘"] and
        latest["收盘"] < prev["开盘"] and
        latest["开盘"] > prev["收盘"]):
        sell_signals.append(("阴包阳形态⚠️", -18))
        sell_score += 18

    # ========== 突破信号 ==========
    # 突破20日新高
    if len(df) >= 20:
        high_20 = df["最高"].tail(20).iloc[:-1].max()
        if latest["收盘"] > high_20:
            buy_signals.append(("突破20日新高", 15))
            buy_score += 15

    # 跌破20日新低
    if len(df) >= 20:
        low_20 = df["最低"].tail(20).iloc[:-1].min()
        if latest["收盘"] < low_20:
            sell_signals.append(("跌破20日新低", -15))
            sell_score += 15

    # ========== 综合判断 ==========
    net_score = buy_score - sell_score
    if net_score >= 50:
        recommendation = "🟢 强烈买入 - 多重买入信号共振"
    elif net_score >= 30:
        recommendation = "🟢 买入 - 多个买入信号"
    elif net_score >= 15:
        recommendation = "🟡 偏多 - 有买入信号但需确认"
    elif net_score <= -50:
        recommendation = "🔴 强烈卖出 - 多重卖出信号共振"
    elif net_score <= -30:
        recommendation = "🔴 卖出 - 多个卖出信号"
    elif net_score <= -15:
        recommendation = "🟡 偏空 - 有卖出信号但需确认"
    else:
        recommendation = "⚪ 观望 - 信号不明确"

    return {
        "buy_signals": buy_signals,
        "sell_signals": sell_signals,
        "buy_score": buy_score,
        "sell_score": sell_score,
        "net_score": net_score,
        "recommendation": recommendation,
        "price": round(latest["收盘"], 2),
        "date": str(latest["日期"].date()) if hasattr(latest["日期"], "date") else str(latest["日期"]),
    }


def stop_loss_take_profit(df: pd.DataFrame, entry_price: float = None) -> dict:
    """计算止损止盈位"""
    if len(df) < 20:
        return {}

    latest = df.iloc[-1]
    price = latest["收盘"]

    if entry_price is None:
        entry_price = price

    ma20 = df["收盘"].rolling(20).mean().iloc[-1]
    boll_low = df["收盘"].rolling(20).mean().iloc[-1] - 2 * df["收盘"].rolling(20).std().iloc[-1]

    # 多种止损策略
    stops = {
        "固定止损(8%)": round(entry_price * 0.92, 2),
        "固定止损(5%)": round(entry_price * 0.95, 2),
        "MA20止损": round(ma20, 2),
        "布林下轨止损": round(boll_low, 2),
    }

    profits = {
        "固定止盈(10%)": round(entry_price * 1.10, 2),
        "固定止盈(20%)": round(entry_price * 1.20, 2),
        "固定止盈(30%)": round(entry_price * 1.30, 2),
    }

    risk_reward = {}
    for sl_name, sl_price in stops.items():
        for tp_name, tp_price in profits.items():
            risk = entry_price - sl_price
            reward = tp_price - entry_price
            if risk > 0:
                ratio = reward / risk
                risk_reward[f"{sl_name} / {tp_name}"] = {
                    "止损": sl_price,
                    "止盈": tp_price,
                    "盈亏比": round(ratio, 2),
                }

    return {
        "入场价": entry_price,
        "现价": round(price, 2),
        "止损位": stops,
        "止盈位": profits,
    }


def format_timing_report(result: dict) -> str:
    """格式化时机报告"""
    if "error" in result:
        return f"❌ {result['error']}"

    lines = []
    lines.append("=" * 50)
    lines.append(f"  ⏰ 买卖时机分析")
    lines.append(f"  日期: {result['date']}  现价: {result['price']}")
    lines.append("=" * 50)

    if result["buy_signals"]:
        lines.append("\n🟢 买入信号:")
        for sig, score in result["buy_signals"]:
            lines.append(f"  ✅ {sig} ({score:+d}分)")

    if result["sell_signals"]:
        lines.append("\n🔴 卖出信号:")
        for sig, score in result["sell_signals"]:
            lines.append(f"  ❌ {sig} ({score:+d}分)")

    lines.append(f"\n📊 买入力: {result['buy_score']} | 卖出力: {result['sell_score']} | 净值: {result['net_score']:+d}")
    lines.append(f"\n💡 {result['recommendation']}")

    return "\n".join(lines)


def get_timing_signal(code: str) -> dict:
    """获取单只股票的买卖信号"""
    df = get_stock_daily(code, start_date=(pd.Timestamp.now() - pd.Timedelta(days=400)).strftime("%Y-%m-%d"))
    if df.empty:
        return {"error": f"无法获取 {code} 的数据"}
    return detect_signals(df)
