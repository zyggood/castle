"""
基本面分析模块
估值、成长性、盈利能力、财务健康
"""

import pandas as pd
import numpy as np
from typing import Dict, List


def analyze_valuation(info: dict, realtime: dict = None) -> dict:
    """
    估值分析
    info: 个股信息
    realtime: 实时行情数据
    """
    result = {
        "PE": None,
        "PB": None,
        "PS": None,
        "估值水平": "未知",
        "score": 0,
    }

    # 从实时行情中提取估值
    pe = realtime.get("市盈率-动态") if realtime else None
    pb = realtime.get("市净率") if realtime else None

    if pe is not None:
        try:
            pe = float(pe)
            result["PE"] = round(pe, 2)
            if pe < 0:
                result["估值水平"] = "亏损"
                result["score"] = -20
            elif pe < 15:
                result["估值水平"] = "低估"
                result["score"] = 25
            elif pe < 25:
                result["估值水平"] = "合理"
                result["score"] = 15
            elif pe < 40:
                result["估值水平"] = "偏高"
                result["score"] = 0
            elif pe < 80:
                result["估值水平"] = "高估"
                result["score"] = -15
            else:
                result["估值水平"] = "严重高估"
                result["score"] = -25
        except:
            pass

    if pb is not None:
        try:
            pb = float(pb)
            result["PB"] = round(pb, 2)
            if pb < 1:
                result["score"] += 15
            elif pb < 2:
                result["score"] += 10
            elif pb < 5:
                result["score"] += 0
            else:
                result["score"] -= 10
        except:
            pass

    return result


def analyze_profitability(financial: dict) -> dict:
    """盈利能力分析"""
    result = {
        "ROE": None,
        "净利率": None,
        "毛利率": None,
        "score": 0,
    }

    indicators = financial.get("财务指标", pd.DataFrame())
    if indicators is None or len(indicators) == 0:
        return result

    try:
        latest = indicators.iloc[0]

        # ROE
        for col in indicators.columns:
            if "净资产收益率" in str(col):
                roe_val = latest[col]
                try:
                    roe = float(str(roe_val).replace("%", ""))
                    result["ROE"] = round(roe, 2)
                    if roe > 20:
                        result["score"] += 25
                    elif roe > 15:
                        result["score"] += 20
                    elif roe > 10:
                        result["score"] += 10
                    elif roe > 5:
                        result["score"] += 5
                    else:
                        result["score"] -= 10
                except:
                    pass
                break

        # 毛利率
        for col in indicators.columns:
            if "毛利率" in str(col):
                try:
                    gm = float(str(latest[col]).replace("%", ""))
                    result["毛利率"] = round(gm, 2)
                    if gm > 40:
                        result["score"] += 15
                    elif gm > 20:
                        result["score"] += 8
                except:
                    pass
                break

        # 净利率
        for col in indicators.columns:
            if "净利率" in str(col) or "净利润率" in str(col):
                try:
                    nm = float(str(latest[col]).replace("%", ""))
                    result["净利率"] = round(nm, 2)
                    if nm > 20:
                        result["score"] += 15
                    elif nm > 10:
                        result["score"] += 8
                except:
                    pass
                break

    except Exception as e:
        pass

    return result


def analyze_growth(financial: dict) -> dict:
    """成长性分析"""
    result = {
        "营收增长率": None,
        "净利润增长率": None,
        "score": 0,
    }

    indicators = financial.get("财务指标", pd.DataFrame())
    if indicators is None or len(indicators) == 0:
        return result

    try:
        latest = indicators.iloc[0]

        for col in indicators.columns:
            col_str = str(col)
            if "营业收入增长率" in col_str or "营收增长率" in col_str:
                try:
                    val = float(str(latest[col]).replace("%", ""))
                    result["营收增长率"] = round(val, 2)
                    if val > 30:
                        result["score"] += 20
                    elif val > 15:
                        result["score"] += 12
                    elif val > 0:
                        result["score"] += 5
                    else:
                        result["score"] -= 10
                except:
                    pass

            if "净利润增长率" in col_str:
                try:
                    val = float(str(latest[col]).replace("%", ""))
                    result["净利润增长率"] = round(val, 2)
                    if val > 30:
                        result["score"] += 25
                    elif val > 15:
                        result["score"] += 15
                    elif val > 0:
                        result["score"] += 5
                    else:
                        result["score"] -= 15
                except:
                    pass

    except:
        pass

    return result


def analyze_financial_health(financial: dict) -> dict:
    """财务健康度分析"""
    result = {
        "资产负债率": None,
        "流动比率": None,
        "score": 0,
    }

    indicators = financial.get("财务指标", pd.DataFrame())
    if indicators is None or len(indicators) == 0:
        return result

    try:
        latest = indicators.iloc[0]

        for col in indicators.columns:
            col_str = str(col)
            if "资产负债率" in col_str:
                try:
                    val = float(str(latest[col]).replace("%", ""))
                    result["资产负债率"] = round(val, 2)
                    if val < 30:
                        result["score"] += 15
                    elif val < 50:
                        result["score"] += 10
                    elif val < 70:
                        result["score"] += 0
                    else:
                        result["score"] -= 15
                except:
                    pass

            if "流动比率" in col_str:
                try:
                    val = float(latest[col])
                    result["流动比率"] = round(val, 2)
                    if val > 2:
                        result["score"] += 10
                    elif val > 1.5:
                        result["score"] += 5
                    elif val < 1:
                        result["score"] -= 10
                except:
                    pass

    except:
        pass

    return result


def full_fundamental_analysis(info: dict, financial: dict,
                               realtime: dict = None) -> dict:
    """完整基本面分析"""
    valuation = analyze_valuation(info, realtime)
    profitability = analyze_profitability(financial)
    growth = analyze_growth(financial)
    health = analyze_financial_health(financial)

    total_score = (
        valuation["score"] * 0.30 +
        profitability["score"] * 0.30 +
        growth["score"] * 0.25 +
        health["score"] * 0.15
    )

    if total_score >= 50:
        rating = "⭐⭐⭐⭐⭐ 优质"
    elif total_score >= 35:
        rating = "⭐⭐⭐⭐ 良好"
    elif total_score >= 20:
        rating = "⭐⭐⭐ 一般"
    elif total_score >= 0:
        rating = "⭐⭐ 较差"
    else:
        rating = "⭐ 差"

    return {
        "估值": valuation,
        "盈利能力": profitability,
        "成长性": growth,
        "财务健康": health,
        "总分": round(total_score, 1),
        "评级": rating,
    }


def format_fundamental_report(result: dict) -> str:
    """格式化基本面报告"""
    lines = []
    lines.append("=" * 50)
    lines.append(f"  📋 基本面分析报告")
    lines.append(f"  综合评分: {result['总分']:.1f} | {result['评级']}")
    lines.append("=" * 50)

    for section in ["估值", "盈利能力", "成长性", "财务健康"]:
        data = result[section]
        score = data.get("score", 0)
        lines.append(f"\n【{section}】 ({score:+d}分)")
        for k, v in data.items():
            if k != "score":
                lines.append(f"  {k}: {v}")

    return "\n".join(lines)
