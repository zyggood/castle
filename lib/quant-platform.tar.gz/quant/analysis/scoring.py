"""
股票综合评分系统
技术面 + 基本面 + 市场面 → 综合评分
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pandas as pd
import numpy as np
from analysis.technical import full_technical_analysis
from analysis.fundamental import full_fundamental_analysis
from data.fetcher import get_stock_daily, get_financial_data, get_stock_info, get_stock_realtime


def comprehensive_score(code: str, verbose: bool = False) -> dict:
    """
    对单只股票进行综合评分
    返回: {
        code, name, tech_score, fund_score, market_score,
        total_score, rating, recommendation, details
    }
    """
    # 获取数据
    df_daily = get_stock_daily(code, start_date=(pd.Timestamp.now() - pd.Timedelta(days=400)).strftime("%Y-%m-%d"))
    if df_daily.empty:
        return {"code": code, "error": "无法获取行情数据"}

    # 实时数据
    rt_df = get_stock_realtime()
    rt_data = {}
    stock_name = code
    if not rt_df.empty:
        row = rt_df[rt_df["代码"] == code]
        if len(row) > 0:
            rt_data = row.iloc[0].to_dict()
            stock_name = rt_data.get("名称", code)

    # 财务数据
    financial = get_financial_data(code)
    info = get_stock_info(code)

    # 技术分析
    tech_result = full_technical_analysis(df_daily)
    tech_score = tech_result.get("总分", 0)

    # 基本面分析
    fund_result = full_fundamental_analysis(info, financial, rt_data)
    fund_score = fund_result.get("总分", 0)

    # 市场面评分（动量+趋势）
    market_score = calc_market_score(df_daily, rt_data)

    # 综合评分（技术40% + 基本面35% + 市场面25%）
    total = tech_score * 0.40 + fund_score * 0.35 + market_score * 0.25

    # 评级
    if total >= 60:
        rating = "S - 极强"
        rec = "🟢 强烈推荐"
    elif total >= 40:
        rating = "A - 强势"
        rec = "🟢 推荐"
    elif total >= 20:
        rating = "B - 偏强"
        rec = "🟡 关注"
    elif total >= 0:
        rating = "C - 中性"
        rec = "⚪ 观望"
    elif total >= -20:
        rating = "D - 偏弱"
        rec = "🟡 谨慎"
    elif total >= -40:
        rating = "E - 弱势"
        rec = "🔴 回避"
    else:
        rating = "F - 极弱"
        rec = "🔴 强烈回避"

    result = {
        "代码": code,
        "名称": stock_name,
        "技术评分": round(tech_score, 1),
        "基本面评分": round(fund_score, 1),
        "市场评分": round(market_score, 1),
        "综合评分": round(total, 1),
        "评级": rating,
        "建议": rec,
    }

    if verbose:
        result["技术详情"] = tech_result
        result["基本面详情"] = fund_result

    return result


def calc_market_score(df: pd.DataFrame, rt_data: dict = None) -> float:
    """市场面评分（动量、趋势、活跃度）"""
    if len(df) < 60:
        return 0

    score = 0

    # 1. 价格动量（20日涨幅）
    if len(df) >= 20:
        mom_20 = (df["收盘"].iloc[-1] / df["收盘"].iloc[-20] - 1) * 100
        if mom_20 > 15:
            score += 20
        elif mom_20 > 5:
            score += 10
        elif mom_20 > 0:
            score += 5
        elif mom_20 > -10:
            score -= 5
        else:
            score -= 15

    # 2. 相对强度（是否跑赢大盘）
    # 用60日涨跌幅
    if len(df) >= 60:
        perf_60 = (df["收盘"].iloc[-1] / df["收盘"].iloc[-60] - 1) * 100
        if perf_60 > 20:
            score += 15
        elif perf_60 > 5:
            score += 8
        elif perf_60 < -20:
            score -= 15
        elif perf_60 < -5:
            score -= 8

    # 3. 换手率活跃度
    if rt_data:
        try:
            turnover = float(rt_data.get("换手率", 0))
            if 3 < turnover < 10:
                score += 10  # 适度活跃
            elif turnover > 15:
                score += 5   # 过度活跃要注意
            elif turnover < 0.5:
                score -= 5   # 太冷清
        except:
            pass

    # 4. 波动率（风险）
    if len(df) >= 20:
        vol = df["收盘"].pct_change().tail(20).std() * np.sqrt(252) * 100
        if vol < 20:
            score += 5  # 低波动加分
        elif vol > 60:
            score -= 10  # 高波动减分

    # 5. 是否站上关键均线
    ma20 = df["收盘"].rolling(20).mean().iloc[-1]
    ma60 = df["收盘"].rolling(60).mean().iloc[-1]
    price = df["收盘"].iloc[-1]

    if price > ma20 > ma60:
        score += 10
    elif price > ma20:
        score += 5
    elif price < ma20 < ma60:
        score -= 10
    elif price < ma20:
        score -= 5

    return score


def batch_score(codes: list, max_workers: int = 1) -> pd.DataFrame:
    """批量评分多只股票"""
    results = []
    for i, code in enumerate(codes):
        print(f"  [{i+1}/{len(codes)}] 分析 {code}...")
        try:
            result = comprehensive_score(code)
            if "error" not in result:
                results.append(result)
        except Exception as e:
            print(f"  ⚠️ {code} 分析失败: {e}")

    if not results:
        return pd.DataFrame()

    df = pd.DataFrame(results)
    df = df.sort_values("综合评分", ascending=False).reset_index(drop=True)
    return df


def format_score_card(result: dict) -> str:
    """格式化评分卡"""
    if "error" in result:
        return f"❌ {result['code']}: {result['error']}"

    lines = []
    lines.append("┌" + "─" * 48 + "┐")
    lines.append(f"│  🏷️  {result['名称']}（{result['代码']}）" +
                 " " * max(1, 48 - len(result['名称']) - len(result['代码']) - 10) + "│")
    lines.append("├" + "─" * 48 + "┤")
    lines.append(f"│  📊 综合评分: {result['综合评分']:+.1f}  |  {result['评级']}" +
                 " " * max(1, 48 - len(str(result['综合评分'])) - len(result['评级']) - 15) + "│")
    lines.append("├" + "─" * 48 + "┤")
    lines.append(f"│  技术面:   {result['技术评分']:+.1f}" +
                 " " * max(1, 35 - len(str(result['技术评分']))) + "│")
    lines.append(f"│  基本面:   {result['基本面评分']:+.1f}" +
                 " " * max(1, 35 - len(str(result['基本面评分']))) + "│")
    lines.append(f"│  市场面:   {result['市场评分']:+.1f}" +
                 " " * max(1, 35 - len(str(result['市场评分']))) + "│")
    lines.append("├" + "─" * 48 + "┤")
    lines.append(f"│  💡 {result['建议']}" +
                 " " * max(1, 48 - len(result['建议']) - 5) + "│")
    lines.append("└" + "─" * 48 + "┘")
    return "\n".join(lines)
