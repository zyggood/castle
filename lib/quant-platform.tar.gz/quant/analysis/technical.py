"""
技术分析模块
MACD, KDJ, RSI, 布林带, 均线系统, 量价分析
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict, List
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import TECHNICAL as CFG


# ============ 均线系统 ============

def calc_ma(df: pd.DataFrame) -> pd.DataFrame:
    """计算各周期均线"""
    df = df.copy()
    df["MA5"] = df["收盘"].rolling(CFG["ma_short"]).mean()
    df["MA10"] = df["收盘"].rolling(10).mean()
    df["MA20"] = df["收盘"].rolling(CFG["ma_mid"]).mean()
    df["MA60"] = df["收盘"].rolling(CFG["ma_long"]).mean()
    df["MA120"] = df["收盘"].rolling(120).mean()
    df["MA250"] = df["收盘"].rolling(250).mean()
    return df


def ma_trend(df: pd.DataFrame) -> dict:
    """判断均线趋势"""
    if len(df) < 60:
        return {"trend": "数据不足", "score": 0}

    latest = df.iloc[-1]
    ma5 = latest.get("MA5", 0)
    ma10 = latest.get("MA10", 0)
    ma20 = latest.get("MA20", 0)
    ma60 = latest.get("MA60", 0)

    # 多头排列: MA5 > MA10 > MA20 > MA60
    bullish = ma5 > ma10 > ma20 > ma60
    # 空头排列
    bearish = ma5 < ma10 < ma20 < ma60

    # 均线角度（5日均线斜率）
    ma5_series = df["MA5"].dropna().tail(5)
    if len(ma5_series) >= 2:
        slope = (ma5_series.iloc[-1] - ma5_series.iloc[0]) / ma5_series.iloc[0] * 100
    else:
        slope = 0

    score = 0
    if bullish:
        score += 40
    elif ma5 > ma20:
        score += 20
    if bearish:
        score -= 40
    elif ma5 < ma20:
        score -= 20

    if slope > 2:
        score += 15
    elif slope > 0:
        score += 5
    elif slope < -2:
        score -= 15
    else:
        score -= 5

    trend = "多头排列" if bullish else ("空头排列" if bearish else "震荡整理")

    return {
        "trend": trend,
        "slope": round(slope, 2),
        "score": score,
        "MA5": round(ma5, 2),
        "MA10": round(ma10, 2),
        "MA20": round(ma20, 2),
        "MA60": round(ma60, 2),
    }


# ============ MACD ============

def calc_macd(df: pd.DataFrame) -> pd.DataFrame:
    """计算MACD指标"""
    df = df.copy()
    fast = CFG["macd_fast"]
    slow = CFG["macd_slow"]
    signal = CFG["macd_signal"]

    ema_fast = df["收盘"].ewm(span=fast, adjust=False).mean()
    ema_slow = df["收盘"].ewm(span=slow, adjust=False).mean()
    df["DIF"] = ema_fast - ema_slow
    df["DEA"] = df["DIF"].ewm(span=signal, adjust=False).mean()
    df["MACD"] = (df["DIF"] - df["DEA"]) * 2
    return df


def macd_signal_detect(df: pd.DataFrame) -> dict:
    """检测MACD金叉/死叉信号"""
    if len(df) < 30:
        return {"signal": "数据不足", "score": 0}

    df = calc_macd(df)
    latest = df.iloc[-1]
    prev = df.iloc[-2]

    dif = latest["DIF"]
    dea = latest["DEA"]
    macd_hist = latest["MACD"]
    prev_hist = prev["MACD"]

    # 金叉：DIF从下穿越DEA
    golden_cross = (prev["DIF"] < prev["DEA"]) and (dif > dea)
    # 死叉：DIF从上穿越DEA
    death_cross = (prev["DIF"] > prev["DEA"]) and (dif < dea)

    # 柱状线变化
    hist_expanding = abs(macd_hist) > abs(prev_hist) and macd_hist > prev_hist
    hist_shrinking = abs(macd_hist) < abs(prev_hist)

    score = 0
    signal_desc = "无明显信号"

    if golden_cross:
        signal_desc = "⭐ MACD金叉"
        score = 30
    elif death_cross:
        signal_desc = "⚠️ MACD死叉"
        score = -30
    elif dif > dea and hist_expanding:
        signal_desc = "多头增强"
        score = 15
    elif dif < dea and macd_hist < prev_hist:
        signal_desc = "空头增强"
        score = -15
    elif dif > dea:
        signal_desc = "多头区间"
        score = 10
    elif dif < dea:
        signal_desc = "空头区间"
        score = -10

    # 零轴判断
    if dif > 0 and dea > 0:
        score += 5
    elif dif < 0 and dea < 0:
        score -= 5

    # 背离检测（简化版）
    divergence = detect_macd_divergence(df)

    return {
        "signal": signal_desc,
        "DIF": round(dif, 4),
        "DEA": round(dea, 4),
        "MACD": round(macd_hist, 4),
        "golden_cross": golden_cross,
        "death_cross": death_cross,
        "divergence": divergence,
        "score": score,
    }


def detect_macd_divergence(df: pd.DataFrame, lookback: int = 30) -> str:
    """检测MACD背离"""
    if len(df) < lookback + 10:
        return "无"

    recent = df.tail(lookback).copy()
    prices = recent["收盘"].values
    macd_vals = recent["MACD"].values

    # 找局部高点和低点
    price_high_idx = np.argmax(prices)
    price_low_idx = np.argmin(prices)
    macd_high_idx = np.argmax(macd_vals)
    macd_low_idx = np.argmin(macd_vals)

    # 顶背离：价格新高但MACD没有新高
    if price_high_idx > len(prices) * 0.7 and macd_high_idx < price_high_idx:
        if prices[price_high_idx] > prices[:price_high_idx].max() * 0.99:
            if macd_vals[price_high_idx] < macd_vals[:price_high_idx].max():
                return "顶背离⚠️"

    # 底背离：价格新低但MACD没有新低
    if price_low_idx > len(prices) * 0.7 and macd_low_idx < price_low_idx:
        if prices[price_low_idx] < prices[:price_low_idx].min() * 1.01:
            if macd_vals[price_low_idx] > macd_vals[:price_low_idx].min():
                return "底背离⭐"

    return "无"


# ============ KDJ ============

def calc_kdj(df: pd.DataFrame) -> pd.DataFrame:
    """计算KDJ指标"""
    df = df.copy()
    n = CFG["kdj_period"]

    low_n = df["最低"].rolling(n).min()
    high_n = df["最高"].rolling(n).max()
    rsv = (df["收盘"] - low_n) / (high_n - low_n + 1e-10) * 100

    df["K"] = rsv.ewm(com=2, adjust=False).mean()
    df["D"] = df["K"].ewm(com=2, adjust=False).mean()
    df["J"] = 3 * df["K"] - 2 * df["D"]
    return df


def kdj_signal(df: pd.DataFrame) -> dict:
    """KDJ信号分析"""
    if len(df) < 15:
        return {"signal": "数据不足", "score": 0}

    df = calc_kdj(df)
    latest = df.iloc[-1]
    prev = df.iloc[-2]

    k, d, j = latest["K"], latest["D"], latest["J"]
    prev_k, prev_d = prev["K"], prev["D"]

    score = 0
    signal_desc = ""

    # 金叉死叉
    golden = prev_k < prev_d and k > d
    death = prev_k > prev_d and k < d

    if golden and k < 30:
        signal_desc = "⭐ KDJ低位金叉（超卖反弹）"
        score = 25
    elif golden:
        signal_desc = "KDJ金叉"
        score = 15
    elif death and k > 70:
        signal_desc = "⚠️ KDJ高位死叉（超买回调）"
        score = -25
    elif death:
        signal_desc = "KDJ死叉"
        score = -15
    elif j > 100:
        signal_desc = "J值超买"
        score = -10
    elif j < 0:
        signal_desc = "J值超卖"
        score = 10
    else:
        signal_desc = f"K:{k:.1f} D:{d:.1f} J:{j:.1f}"

    return {
        "signal": signal_desc,
        "K": round(k, 2),
        "D": round(d, 2),
        "J": round(j, 2),
        "golden_cross": golden,
        "death_cross": death,
        "score": score,
    }


# ============ RSI ============

def calc_rsi(df: pd.DataFrame) -> pd.DataFrame:
    """计算RSI指标"""
    df = df.copy()
    period = CFG["rsi_period"]
    delta = df["收盘"].diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)

    avg_gain = gain.ewm(alpha=1/period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, adjust=False).mean()
    rs = avg_gain / (avg_loss + 1e-10)
    df["RSI"] = 100 - (100 / (1 + rs))

    # RSI6, RSI12, RSI24
    for p in [6, 12, 24]:
        ag = gain.ewm(alpha=1/p, adjust=False).mean()
        al = loss.ewm(alpha=1/p, adjust=False).mean()
        r = ag / (al + 1e-10)
        df[f"RSI{p}"] = 100 - (100 / (1 + r))

    return df


def rsi_signal(df: pd.DataFrame) -> dict:
    """RSI信号分析"""
    if len(df) < 30:
        return {"signal": "数据不足", "score": 0}

    df = calc_rsi(df)
    latest = df.iloc[-1]
    rsi = latest["RSI"]
    rsi6 = latest.get("RSI6", rsi)
    rsi12 = latest.get("RSI12", rsi)
    rsi24 = latest.get("RSI24", rsi)

    ob = CFG["rsi_overbought"]
    os_ = CFG["rsi_oversold"]

    score = 0
    if rsi < os_:
        signal_desc = "⭐ RSI超卖区间"
        score = 20
    elif rsi > ob:
        signal_desc = "⚠️ RSI超买区间"
        score = -20
    elif rsi6 > rsi12 > rsi24:
        signal_desc = "RSI多头排列"
        score = 10
    elif rsi6 < rsi12 < rsi24:
        signal_desc = "RSI空头排列"
        score = -10
    else:
        signal_desc = f"RSI={rsi:.1f}"

    return {
        "signal": signal_desc,
        "RSI": round(rsi, 2),
        "RSI6": round(rsi6, 2),
        "RSI12": round(rsi12, 2),
        "RSI24": round(rsi24, 2),
        "score": score,
    }


# ============ 布林带 ============

def calc_boll(df: pd.DataFrame) -> pd.DataFrame:
    """计算布林带"""
    df = df.copy()
    period = CFG["boll_period"]
    std_mult = CFG["boll_std"]

    df["BOLL_MID"] = df["收盘"].rolling(period).mean()
    std = df["收盘"].rolling(period).std()
    df["BOLL_UP"] = df["BOLL_MID"] + std_mult * std
    df["BOLL_LOW"] = df["BOLL_MID"] - std_mult * std
    df["BOLL_WIDTH"] = (df["BOLL_UP"] - df["BOLL_LOW"]) / df["BOLL_MID"] * 100
    return df


def boll_signal(df: pd.DataFrame) -> dict:
    """布林带信号分析"""
    if len(df) < 25:
        return {"signal": "数据不足", "score": 0}

    df = calc_boll(df)
    latest = df.iloc[-1]
    price = latest["收盘"]
    up = latest["BOLL_UP"]
    mid = latest["BOLL_MID"]
    low = latest["BOLL_LOW"]
    width = latest["BOLL_WIDTH"]

    score = 0
    if price <= low:
        signal_desc = "⭐ 触及下轨（超卖）"
        score = 20
    elif price >= up:
        signal_desc = "⚠️ 触及上轨（超买）"
        score = -20
    elif price > mid:
        signal_desc = "中轨上方运行"
        score = 5
    else:
        signal_desc = "中轨下方运行"
        score = -5

    # 布林带收窄（可能变盘）
    width_series = df["BOLL_WIDTH"].dropna().tail(20)
    if len(width_series) > 0 and width < width_series.quantile(0.2):
        signal_desc += " | 带宽收窄⚡（注意变盘）"

    return {
        "signal": signal_desc,
        "price": round(price, 2),
        "UP": round(up, 2),
        "MID": round(mid, 2),
        "LOW": round(low, 2),
        "width": round(width, 2),
        "score": score,
    }


# ============ 量价分析 ============

def volume_analysis(df: pd.DataFrame) -> dict:
    """量价关系分析"""
    if len(df) < 10:
        return {"signal": "数据不足", "score": 0}

    latest = df.iloc[-1]
    vol = latest["成交量"]
    vol_ma5 = df["成交量"].rolling(5).mean().iloc[-1]
    vol_ma10 = df["成交量"].rolling(10).mean().iloc[-1]
    vol_ratio = vol / (vol_ma5 + 1e-10)

    price_change = latest["涨跌幅"]

    score = 0
    if vol_ratio > 2.0 and price_change > 2:
        signal_desc = "放量上涨📈"
        score = 20
    elif vol_ratio > 2.0 and price_change < -2:
        signal_desc = "放量下跌📉"
        score = -20
    elif vol_ratio < 0.5 and abs(price_change) < 1:
        signal_desc = "缩量整理"
        score = 0
    elif vol_ratio > 1.5:
        signal_desc = "放量"
        score = 5
    elif vol_ratio < 0.7:
        signal_desc = "缩量"
        score = -3
    else:
        signal_desc = "量能平稳"

    # 连续放量/缩量
    recent_vol = df["成交量"].tail(5)
    recent_ma = df["成交量"].rolling(20).mean().tail(5)
    if len(recent_vol) >= 5 and len(recent_ma.dropna()) >= 5:
        above_ma = (recent_vol.values > recent_ma.dropna().values[:5]).sum()
        if above_ma >= 4:
            signal_desc += " | 连续放量"
        elif above_ma <= 1:
            signal_desc += " | 连续缩量"

    return {
        "signal": signal_desc,
        "vol_ratio": round(vol_ratio, 2),
        "vol_ma5": int(vol_ma5),
        "vol_ma10": int(vol_ma10),
        "score": score,
    }


# ============ 综合技术评分 ============

def full_technical_analysis(df: pd.DataFrame) -> dict:
    """完整技术分析评分"""
    if len(df) < 60:
        return {"error": "数据不足60个交易日", "total_score": 0}

    df = calc_ma(df)
    df = calc_macd(df)
    df = calc_kdj(df)
    df = calc_rsi(df)
    df = calc_boll(df)

    ma_result = ma_trend(df)
    macd_result = macd_signal_detect(df)
    kdj_result = kdj_signal(df)
    rsi_result = rsi_signal(df)
    boll_result = boll_signal(df)
    vol_result = volume_analysis(df)

    total_score = (
        ma_result["score"] * 0.20 +
        macd_result["score"] * 0.25 +
        kdj_result["score"] * 0.20 +
        rsi_result["score"] * 0.15 +
        boll_result["score"] * 0.10 +
        vol_result["score"] * 0.10
    )

    # 判断买卖建议
    if total_score >= 40:
        recommendation = "🟢 强烈买入"
    elif total_score >= 20:
        recommendation = "🟢 买入"
    elif total_score >= 10:
        recommendation = "🟡 偏多"
    elif total_score <= -40:
        recommendation = "🔴 强烈卖出"
    elif total_score <= -20:
        recommendation = "🔴 卖出"
    elif total_score <= -10:
        recommendation = "🟡 偏空"
    else:
        recommendation = "⚪ 观望"

    return {
        "均线": ma_result,
        "MACD": macd_result,
        "KDJ": kdj_result,
        "RSI": rsi_result,
        "布林带": boll_result,
        "量价": vol_result,
        "总分": round(total_score, 1),
        "建议": recommendation,
    }


def format_technical_report(result: dict) -> str:
    """格式化技术分析报告"""
    lines = []
    lines.append("=" * 50)
    lines.append(f"  📊 技术分析报告")
    lines.append(f"  综合评分: {result['总分']:.1f} | {result['建议']}")
    lines.append("=" * 50)

    for section in ["均线", "MACD", "KDJ", "RSI", "布林带", "量价"]:
        data = result[section]
        sig = data.get("signal", "")
        score = data.get("score", 0)
        lines.append(f"\n【{section}】 {sig}  ({score:+d}分)")
        for k, v in data.items():
            if k not in ("signal", "score", "golden_cross", "death_cross"):
                lines.append(f"  {k}: {v}")

    return "\n".join(lines)
