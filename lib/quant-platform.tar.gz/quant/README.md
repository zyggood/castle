# A股量化平台

个人量化选股和交易分析平台，针对A股市场。

## 功能

| 功能 | 命令 | 说明 |
|------|------|------|
| 综合分析 | `python3 main.py report <代码>` | 完整评估报告（技术+基本面+信号+回测） |
| 股票评分 | `python3 main.py score <代码>` | 综合评分卡（S/A/B/C/D/F） |
| 买卖信号 | `python3 main.py signal <代码>` | 多维度买卖信号检测 |
| 选股 | `python3 main.py screen [策略]` | 多因子选股 |
| 涨幅排行 | `python3 main.py top [N]` | 实时涨幅排名 |
| 搜索 | `python3 main.py search <关键词>` | 搜索股票 |
| 回测 | `python3 main.py backtest <代码> [策略]` | 策略回测 |
| 多策略 | `python3 main.py multi` | 多策略交叉选股 |
| 交互模式 | `python3 main.py interactive` | 命令行交互 |

## 选股策略

- **价值**: 低PE + 低PB 价值股
- **成长**: 高涨幅 + 活跃成交 成长股
- **动量**: 强势股 + 持续上涨
- **反转**: 超跌反弹候选
- **龙头**: 板块龙头
- **低估值优质**: 综合PE/PB/活跃度

## 回测策略

- `MA5/MA20` — 短期均线交叉
- `MA10/MA30` — 中期均线交叉
- `MA20/MA60` — 中长期均线交叉
- `MACD` — MACD金叉死叉
- `KDJ` — KDJ低位金叉/高位死叉

## 技术指标

均线系统(MA5/10/20/60/120/250)、MACD、KDJ、RSI(6/12/24)、布林带、量价分析、K线形态识别（阳包阴/阴包阳）、背离检测

## 评分体系

- **技术面(40%)**: 均线趋势 + MACD + KDJ + RSI + 布林带 + 量价
- **基本面(35%)**: 估值(PE/PB) + 盈利能力(ROE/毛利率) + 成长性 + 财务健康
- **市场面(25%)**: 价格动量 + 相对强度 + 换手率 + 波动率 + 均线位置

## 示例

```bash
# 完整报告
python3 main.py report 300750

# 选股
python3 main.py screen 价值
python3 main.py screen 成长

# 回测
python3 main.py backtest 600519 MACD

# 交互模式
python3 main.py interactive
```

## 配置

编辑 `config.py` 调整参数：
- 选股条件（市值/PE/PB/ROE阈值）
- 技术指标参数
- 回测参数（初始资金/佣金/印花税）
- 风控参数（止损止盈/最大仓位）

## 数据源

腾讯行情API（实时行情 + 日K历史数据），无需API Key。

## 依赖

```
pandas numpy matplotlib ta
```
