"""
数据获取模块 - 多数据源（腾讯行情为主）
A股行情、财务等数据
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import json
import os
import urllib.request
import urllib.parse
import re

CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://finance.qq.com",
}


def _http_get(url: str, timeout: int = 15, encoding: str = None) -> str:
    """简单的HTTP GET，自动处理编码"""
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        if encoding:
            return raw.decode(encoding, errors="ignore")
        # 检测charset
        charset = resp.headers.get_content_charset()
        if charset:
            return raw.decode(charset, errors="ignore")
        # 腾讯行情是GBK
        for enc in ["gbk", "gb18030", "gb2312", "utf-8"]:
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        return raw.decode("utf-8", errors="ignore")


def _cache_path(name: str) -> str:
    return os.path.join(CACHE_DIR, f"{name}.json")


def _is_fresh(name: str, hours: int = 4) -> bool:
    path = _cache_path(name)
    if not os.path.exists(path):
        return False
    return (time.time() - os.path.getmtime(path)) < hours * 3600


def _load_cache(name: str):
    path = _cache_path(name)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return None


def _save_cache(name: str, data):
    path = _cache_path(name)
    with open(path, "w") as f:
        json.dump(data, f, ensure_ascii=False, default=str)


# ============ 腾讯行情API ============

def _tencent_quote(codes: list) -> dict:
    """
    通过腾讯行情接口获取实时报价
    codes: ['sh000001', 'sz000001', ...]
    返回: {code: {name, price, change, change_pct, ...}}
    """
    if not codes:
        return {}

    results = {}
    # 批量查询，每批最多50只
    for i in range(0, len(codes), 50):
        batch = codes[i:i+50]
        url = f"https://qt.gtimg.cn/q={','.join(batch)}"
        try:
            text = _http_get(url)
            for line in text.strip().split(";"):
                line = line.strip()
                if not line or "=" not in line:
                    continue
                # v_sh000001="1~上证指数~000001~..."
                var_name, _, val = line.partition("=")
                val = val.strip().strip('"')
                if not val:
                    continue

                # 提取市场和代码
                code_match = re.search(r'v_(sh|sz|bj)(\d{6})', var_name)
                if not code_match:
                    continue
                market = code_match.group(1)
                stock_code = code_match.group(2)
                full_code = f"{market}{stock_code}"

                fields = val.split("~")
                if len(fields) < 45:
                    continue

                results[stock_code] = {
                    "代码": stock_code,
                    "名称": fields[1].replace(" ", ""),
                    "最新价": float(fields[3]) if fields[3] else 0,
                    "昨收": float(fields[4]) if fields[4] else 0,
                    "今开": float(fields[5]) if fields[5] else 0,
                    "成交量": int(fields[6]) if fields[6] else 0,  # 手
                    "成交额": float(fields[37]) * 10000 if fields[37] else 0,  # 万→元
                    "最高": float(fields[33]) if fields[33] else 0,
                    "最低": float(fields[34]) if fields[34] else 0,
                    "涨跌幅": float(fields[32]) if fields[32] else 0,
                    "涨跌额": float(fields[31]) if fields[31] else 0,
                    "振幅": float(fields[43]) if len(fields) > 43 and fields[43] else 0,
                    "换手率": float(fields[38]) if len(fields) > 38 and fields[38] else 0,
                    "市盈率-动态": float(fields[39]) if len(fields) > 39 and fields[39] else 0,
                    "市净率": float(fields[46]) if len(fields) > 46 and fields[46] else 0,
                    "总市值": float(fields[45]) * 1e8 if len(fields) > 45 and fields[45] else 0,  # 亿→元
                    "流通市值": float(fields[44]) * 1e8 if len(fields) > 44 and fields[44] else 0,
                    "时间": fields[30] if len(fields) > 30 else "",
                }
        except Exception as e:
            print(f"[腾讯行情获取失败] batch {i}: {e}")

    return results


def get_stock_daily(code: str, start_date: str = None, end_date: str = None,
                    adjust: str = "qfq") -> pd.DataFrame:
    """
    获取个股日K数据 - 使用腾讯历史行情
    code: 股票代码，如 '000001'
    """
    if end_date is None:
        end_date = datetime.now().strftime("%Y-%m-%d")
    if start_date is None:
        start_date = (datetime.now() - timedelta(days=400)).strftime("%Y-%m-%d")

    # 确保是字符串
    start_date = str(start_date)
    end_date = str(end_date)

    # 统一日期格式为 YYYY-MM-DD
    start_date = start_date.replace("/", "-").replace(".", "-")
    end_date = end_date.replace("/", "-").replace(".", "-")
    if len(start_date) == 8 and "-" not in start_date:
        start_date = f"{start_date[:4]}-{start_date[4:6]}-{start_date[6:]}"
    if len(end_date) == 8 and "-" not in end_date:
        end_date = f"{end_date[:4]}-{end_date[4:6]}-{end_date[6:]}"

    # 判断市场
    if code.startswith("6") or code.startswith("9"):
        market = "sh"
    else:
        market = "sz"

    cache_key = f"daily_{code}"
    if _is_fresh(cache_key, hours=6):
        cached = _load_cache(cache_key)
        if cached:
            df = pd.DataFrame(cached)
            df["日期"] = pd.to_datetime(df["日期"])
            return df

    # 使用腾讯日K接口 — 格式: YYYY-MM-DD
    url = (f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?"
           f"param={market}{code},day,{start_date},,500,qfq")
    try:
        text = _http_get(url, encoding="utf-8")
        data = json.loads(text)

        key = f"{market}{code}"
        if "data" in data and key in data["data"]:
            stock_data = data["data"][key]

            # 优先前复权数据
            kline_key = "qfqday" if adjust == "qfq" else "day"
            if kline_key not in stock_data:
                kline_key = "day"

            klines = stock_data.get(kline_key, [])
            if not klines:
                return pd.DataFrame()

            records = []
            for k in klines:
                if len(k) >= 6:
                    records.append({
                        "日期": k[0],
                        "开盘": float(k[1]),
                        "收盘": float(k[2]),
                        "最高": float(k[3]),
                        "最低": float(k[4]),
                        "成交量": float(k[5]),
                    })

            if records:
                df = pd.DataFrame(records)
                df["日期"] = pd.to_datetime(df["日期"])
                for col in ["开盘", "收盘", "最高", "最低"]:
                    df[col] = df[col].astype(float)
                df["成交量"] = df["成交量"].astype(float)
                df = df.sort_values("日期").reset_index(drop=True)

                # 补充涨跌幅等
                df["涨跌幅"] = df["收盘"].pct_change() * 100
                df["涨跌额"] = df["收盘"].diff()

                _save_cache(cache_key, df.to_dict("records"))
                return df
    except Exception as e:
        print(f"[日K获取失败] {code}: {e}")

    return pd.DataFrame()


def get_stock_realtime() -> pd.DataFrame:
    """获取全部A股实时行情（简化版，使用常用股票列表）"""
    cache_key = "realtime_all"
    if _is_fresh(cache_key, hours=1):
        cached = _load_cache(cache_key)
        if cached:
            return pd.DataFrame(cached)

    # 构建主要股票列表 - 从在线获取
    try:
        # 尝试获取沪深A股列表
        url = "https://proxy.finance.qq.com/ifzqgtimg/appstock/app/newfqkline/get?param=sh000001,day,,,250,qfq"
        text = _http_get(url)
        # 这只是测试连通性
        print("  网络连接正常")
    except:
        pass

    # 使用预定义的重要股票列表 + 腾讯批量查询
    important_codes = _get_stock_list()
    quotes = _tencent_quote(important_codes)

    if quotes:
        df = pd.DataFrame(quotes.values())
        _save_cache(cache_key, df.to_dict("records"))
        return df

    return pd.DataFrame()


def _get_stock_list() -> list:
    """获取需要监控的股票代码列表（腾讯格式: sh/sz + 6位代码）"""
    # 沪深300主要成分 + 热门股
    codes = []

    # 主要指数
    codes.extend(["sh000001", "sz399001", "sz399006", "sh000300", "sh000905"])

    # 沪市主板（600/601/603/605开头）主要股票
    sh_stocks = [
        "600519", "601318", "600036", "601166", "600276",  # 茅台、平安、招商、兴业、恒瑞
        "601888", "600887", "603259", "600900", "601012",  # 中免、伊利、药明、隆基
        "600809", "600585", "603501", "601899", "600309",  # 山西汾酒、海螺水泥、韦尔、紫金、万华
        "601398", "601288", "600000", "600030", "601688",  # 工行、农行、浦发、中信、华泰
        "601601", "601336", "600588", "603160", "688111",  # 太保、新华、用友、汇顶
        "600028", "601857", "600104", "601633", "603986",  # 中石化、中石油、上汽、长城、兆易
    ]
    codes.extend([f"sh{c}" for c in sh_stocks])

    # 深市主板 + 中小板（000/001/002开头）
    sz_stocks = [
        "000858", "000568", "000333", "000651", "002714",  # 五粮液、泸州老窖、美的、格力、牧原
        "002415", "002304", "000002", "002352", "002475",  # 海康、洋河、万科、顺丰、立讯
        "002142", "002594", "000538", "002049", "002241",  # 宁波银行、比亚迪、云南白药、紫光、歌尔
        "000166", "000776", "002027", "000895", "002466",  # 申万宏源、广发证券、分众、双汇、天齐
        "002371", "002601", "000661", "002230", "000063",  # 北方华创、龙佰、长春高新、科大讯飞、中兴
        "000725", "002050", "002920", "002555", "000876",  # 京东方A、三花智控、德赛西威、三七互娱、新希望
    ]
    codes.extend([f"sz{c}" for c in sz_stocks])

    # 创业板（300/301开头）
    cy_stocks = [
        "300750", "300059", "300015", "300760", "300124",  # 宁德时代、东方财富、爱尔眼科、迈瑞医疗、汇川技术
        "300274", "300014", "300408", "300628", "300347",  # 阳光电源、亿纬锂能、三环集团、亿联网络、泰格医药
        "300496", "300601", "300759", "300033", "300003",  # 中科创达、亿纬锂能、康龙化成、同花顺、乐普医疗
        "300122", "300529", "300604", "300595", "300450",  # 智飞生物、健帆生物、长川科技、欧普康视、先导智能
    ]
    codes.extend([f"sz{c}" for c in cy_stocks])

    # 科创板（688开头）
    kc_stocks = [
        "688111", "688981", "688036", "688599", "688005",  # 金山办公、中芯国际、传音控股、天合光能、容百科技
        "688169", "688396", "688063", "688187", "688256",  # 石头科技、华润微、派能科技、时代电气、寒武纪
    ]
    codes.extend([f"sh{c}" for c in kc_stocks])

    return codes


def get_stock_name(code: str) -> str:
    """根据代码获取股票名称"""
    if code.startswith("6"):
        market = "sh"
    else:
        market = "sz"

    quotes = _tencent_quote([f"{market}{code}"])
    if code in quotes:
        return quotes[code]["名称"]
    return code


def search_stock(keyword: str) -> pd.DataFrame:
    """搜索股票（从全量数据中搜索）"""
    df = get_stock_realtime()
    if df.empty:
        return pd.DataFrame()

    mask = df["代码"].str.contains(keyword) | df["名称"].str.contains(keyword, na=False)
    return df[mask].head(20)


def get_top_stocks(top_n: int = 50) -> pd.DataFrame:
    """获取涨跌幅排行"""
    df = get_stock_realtime()
    if df.empty:
        return pd.DataFrame()

    if "涨跌幅" in df.columns:
        df = df.sort_values("涨跌幅", ascending=False).head(top_n)
    return df


def get_stock_info(code: str) -> dict:
    """获取个股基本信息（从实时行情中提取）"""
    if code.startswith("6"):
        market = "sh"
    else:
        market = "sz"

    quotes = _tencent_quote([f"{market}{code}"])
    if code in quotes:
        return quotes[code]
    return {}


def get_financial_data(code: str) -> dict:
    """
    获取财务数据（从腾讯接口获取简要财务指标）
    注：完整财务数据需要专业数据源，此处提供基础估值数据
    """
    result = {}
    if code.startswith("6"):
        market = "sh"
    else:
        market = "sz"

    quotes = _tencent_quote([f"{market}{code}"])
    if code in quotes:
        q = quotes[code]
        result["估值"] = {
            "市盈率": q.get("市盈率-动态", 0),
            "市净率": q.get("市净率", 0),
            "总市值": q.get("总市值", 0),
            "流通市值": q.get("流通市值", 0),
        }
    return result


def get_market_index(index_code: str = "000300") -> pd.DataFrame:
    """获取大盘指数数据"""
    market = "sh" if index_code.startswith("0") or index_code.startswith("9") else "sz"
    df = get_stock_daily(index_code)
    return df


def batch_quote(codes: list) -> dict:
    """批量获取实时行情"""
    tencent_codes = []
    for c in codes:
        if c.startswith("6"):
            tencent_codes.append(f"sh{c}")
        else:
            tencent_codes.append(f"sz{c}")
    return _tencent_quote(tencent_codes)
