"""
A股量化平台 - 综合评估报告
一键生成单只股票的完整评估报告
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pandas as pd
from data.fetcher import get_stock_daily, get_stock_info, get_financial_data, get_stock_realtime
from analysis.technical import full_technical_analysis, format_technical_report, calc_ma, calc_macd, calc_kdj, calc_rsi, calc_boll
from analysis.fundamental import full_fundamental_analysis, format_fundamental_report
from analysis.scoring import comprehensive_score, format_score_card
from signals.timing import get_timing_signal, format_timing_report, stop_loss_take_profit
from backtest.engine import run_backtest, format_backtest_report


def full_report(code: str, backtest_strategy: str = "MA5/MA20") -> str:
    """生成单只股票的完整评估报告"""
    lines = []
    lines.append("\n" + "█" * 60)
    lines.append(f"  🔬 量化分析报告 - 股票代码: {code}")
    lines.append("█" * 60)

    # 1. 获取基础数据
    df = get_stock_daily(code, start_date=(pd.Timestamp.now() - pd.Timedelta(days=500)).strftime("%Y-%m-%d"))
    if df.empty:
        return f"❌ 无法获取 {code} 的数据"

    # 2. 基本信息
    rt_df = get_stock_realtime()
    rt_data = {}
    stock_name = code
    if not rt_df.empty:
        row = rt_df[rt_df["代码"] == code]
        if len(row) > 0:
            rt_data = row.iloc[0].to_dict()
            stock_name = rt_data.get("名称", code)

    lines.append(f"\n📌 {stock_name}（{code}）")
    if rt_data:
        price = rt_data.get("最新价", "N/A")
        change = rt_data.get("涨跌幅", 0)
        lines.append(f"  现价: {price}  涨跌幅: {change:+.2f}%")
        lines.append(f"  PE: {rt_data.get('市盈率-动态', 'N/A')}  PB: {rt_data.get('市净率', 'N/A')}")
        lines.append(f"  成交额: {rt_data.get('成交额', 0)/1e8:.1f}亿  换手率: {rt_data.get('换手率', 'N/A')}%")

    # 3. 综合评分卡
    score_result = comprehensive_score(code)
    lines.append("")
    lines.append(format_score_card(score_result))

    # 4. 技术分析
    tech = full_technical_analysis(df)
    lines.append("")
    lines.append(format_technical_report(tech))

    # 5. 买卖信号
    timing = get_timing_signal(code)
    lines.append("")
    lines.append(format_timing_report(timing))

    # 6. 止损止盈建议
    df_teched = calc_boll(calc_rsi(calc_kdj(calc_macd(calc_ma(df)))))
    sl_tp = stop_loss_take_profit(df_teched)
    if sl_tp:
        lines.append("\n" + "-" * 50)
        lines.append("  🛡️ 止损止盈建议")
        lines.append("-" * 50)
        lines.append(f"  现价: {sl_tp['现价']}")
        lines.append("\n  止损位:")
        for name, price in sl_tp.get("止损位", {}).items():
            lines.append(f"    {name}: {price}")
        lines.append("\n  止盈位:")
        for name, price in sl_tp.get("止盈位", {}).items():
            lines.append(f"    {name}: {price}")

    # 7. 回测
    bt = run_backtest(code, strategy=backtest_strategy)
    lines.append("")
    lines.append(format_backtest_report(bt))

    lines.append("\n" + "█" * 60)
    lines.append("  📝 报告生成完毕")
    lines.append("█" * 60)

    return "\n".join(lines)
