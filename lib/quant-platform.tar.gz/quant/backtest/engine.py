"""
回测引擎
支持策略回测、收益分析、风险评估
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pandas as pd
import numpy as np
from datetime import datetime
from config import BACKTEST as CFG


class BacktestEngine:
    """回测引擎"""

    def __init__(self, initial_capital: float = None,
                 commission: float = None,
                 stamp_tax: float = None,
                 slippage: float = None):
        self.initial_capital = initial_capital or CFG["initial_capital"]
        self.commission = commission or CFG["commission_rate"]
        self.stamp_tax = stamp_tax or CFG["stamp_tax_rate"]
        self.slippage = slippage or CFG["slippage"]

        self.cash = self.initial_capital
        self.position = 0  # 持仓数量
        self.entry_price = 0
        self.trades = []
        self.daily_values = []

    def reset(self):
        """重置引擎"""
        self.cash = self.initial_capital
        self.position = 0
        self.entry_price = 0
        self.trades = []
        self.daily_values = []

    def buy(self, date, price: float, shares: int = None):
        """买入"""
        if self.position > 0:
            return False  # 已有持仓

        price_with_slippage = price * (1 + self.slippage)

        if shares is None:
            # 全仓买入（至少买1手）
            max_amount = self.cash / (1 + self.commission)
            shares = int(max_amount / price_with_slippage / 100) * 100  # 整手
            if shares == 0 and self.cash >= price_with_slippage * 100:
                shares = 100  # 资金不够满仓但够1手

        if shares <= 0:
            return False

        cost = shares * price_with_slippage
        commission_fee = cost * self.commission
        total_cost = cost + commission_fee

        if total_cost > self.cash:
            return False

        self.cash -= total_cost
        self.position = shares
        self.entry_price = price_with_slippage

        self.trades.append({
            "date": date,
            "type": "买入",
            "price": round(price_with_slippage, 2),
            "shares": shares,
            "amount": round(total_cost, 2),
            "commission": round(commission_fee, 2),
        })
        return True

    def sell(self, date, price: float, shares: int = None):
        """卖出"""
        if self.position <= 0:
            return False

        price_with_slippage = price * (1 - self.slippage)

        if shares is None:
            shares = self.position

        shares = min(shares, self.position)

        revenue = shares * price_with_slippage
        commission_fee = revenue * self.commission
        stamp_tax_fee = revenue * self.stamp_tax
        net_revenue = revenue - commission_fee - stamp_tax_fee

        self.cash += net_revenue
        self.position -= shares

        pnl = (price_with_slippage - self.entry_price) * shares

        self.trades.append({
            "date": date,
            "type": "卖出",
            "price": round(price_with_slippage, 2),
            "shares": shares,
            "amount": round(net_revenue, 2),
            "commission": round(commission_fee, 2),
            "stamp_tax": round(stamp_tax_fee, 2),
            "pnl": round(pnl, 2),
        })

        if self.position == 0:
            self.entry_price = 0

        return True

    def record_daily(self, date, price: float):
        """记录每日资产"""
        value = self.cash + self.position * price
        self.daily_values.append({
            "date": date,
            "cash": round(self.cash, 2),
            "position_value": round(self.position * price, 2),
            "total_value": round(value, 2),
        })

    def get_stats(self) -> dict:
        """计算回测统计"""
        if not self.daily_values:
            return {"error": "无回测数据"}

        df = pd.DataFrame(self.daily_values)
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date")

        final_value = df["total_value"].iloc[-1]
        total_return = (final_value / self.initial_capital - 1) * 100

        # 年化收益
        days = (df.index[-1] - df.index[0]).days
        annual_return = ((final_value / self.initial_capital) ** (365 / max(days, 1)) - 1) * 100

        # 最大回撤
        cummax = df["total_value"].cummax()
        drawdown = (df["total_value"] - cummax) / cummax * 100
        max_drawdown = drawdown.min()

        # 夏普比率（简化）
        returns = df["total_value"].pct_change().dropna()
        if len(returns) > 1 and returns.std() > 0:
            sharpe = returns.mean() / returns.std() * np.sqrt(252)
        else:
            sharpe = 0

        # 交易统计
        buy_trades = [t for t in self.trades if t["type"] == "买入"]
        sell_trades = [t for t in self.trades if t["type"] == "卖出"]
        winning = [t for t in sell_trades if t.get("pnl", 0) > 0]
        losing = [t for t in sell_trades if t.get("pnl", 0) <= 0]

        total_commission = sum(t.get("commission", 0) for t in self.trades)
        total_stamp_tax = sum(t.get("stamp_tax", 0) for t in self.trades)

        return {
            "初始资金": self.initial_capital,
            "最终资金": round(final_value, 2),
            "总收益": round(final_value - self.initial_capital, 2),
            "总收益率(%)": round(total_return, 2),
            "年化收益率(%)": round(annual_return, 2),
            "最大回撤(%)": round(max_drawdown, 2),
            "夏普比率": round(sharpe, 2),
            "交易次数": len(buy_trades),
            "胜率(%)": round(len(winning) / max(len(sell_trades), 1) * 100, 1),
            "盈利次数": len(winning),
            "亏损次数": len(losing),
            "总佣金": round(total_commission, 2),
            "总印花税": round(total_stamp_tax, 2),
            "净值曲线": df["total_value"].tolist(),
            "日期序列": df.index.strftime("%Y-%m-%d").tolist(),
        }


def backtest_ma_cross(df: pd.DataFrame, short: int = 5, long: int = 20,
                      initial_capital: float = 100000) -> dict:
    """
    均线交叉策略回测
    MA短线上穿MA长线 → 买入
    MA短线下穿MA长线 → 卖出
    """
    if len(df) < long + 5:
        return {"error": "数据不足"}

    engine = BacktestEngine(initial_capital=initial_capital)
    df = df.copy()
    df[f"MA{short}"] = df["收盘"].rolling(short).mean()
    df[f"MA{long}"] = df["收盘"].rolling(long).mean()

    for i in range(1, len(df)):
        row = df.iloc[i]
        prev = df.iloc[i - 1]
        date = row["日期"]
        price = row["收盘"]

        ma_s = row[f"MA{short}"]
        ma_l = row[f"MA{long}"]
        prev_ma_s = prev[f"MA{short}"]
        prev_ma_l = prev[f"MA{long}"]

        # 金叉买入
        if prev_ma_s < prev_ma_l and ma_s > ma_l and engine.position == 0:
            engine.buy(date, price)

        # 死叉卖出
        elif prev_ma_s > prev_ma_l and ma_s < ma_l and engine.position > 0:
            engine.sell(date, price)

        engine.record_daily(date, price)

    # 如果最后还有持仓，按最后价格平仓
    if engine.position > 0:
        last = df.iloc[-1]
        engine.sell(last["日期"], last["收盘"])

    stats = engine.get_stats()
    stats["策略"] = f"MA{short}/MA{long}均线交叉"
    return stats


def backtest_macd_strategy(df: pd.DataFrame, initial_capital: float = 100000) -> dict:
    """MACD策略回测"""
    if len(df) < 35:
        return {"error": "数据不足"}

    from analysis.technical import calc_macd
    engine = BacktestEngine(initial_capital=initial_capital)
    df = calc_macd(df)

    for i in range(1, len(df)):
        row = df.iloc[i]
        prev = df.iloc[i - 1]
        date = row["日期"]
        price = row["收盘"]

        # MACD金叉买入
        if prev["DIF"] < prev["DEA"] and row["DIF"] > row["DEA"] and engine.position == 0:
            engine.buy(date, price)

        # MACD死叉卖出
        elif prev["DIF"] > prev["DEA"] and row["DIF"] < row["DEA"] and engine.position > 0:
            engine.sell(date, price)

        engine.record_daily(date, price)

    if engine.position > 0:
        last = df.iloc[-1]
        engine.sell(last["日期"], last["收盘"])

    stats = engine.get_stats()
    stats["策略"] = "MACD金叉死叉"
    return stats


def backtest_kdj_strategy(df: pd.DataFrame, initial_capital: float = 100000) -> dict:
    """KDJ策略回测"""
    if len(df) < 15:
        return {"error": "数据不足"}

    from analysis.technical import calc_kdj
    engine = BacktestEngine(initial_capital=initial_capital)
    df = calc_kdj(df)

    for i in range(1, len(df)):
        row = df.iloc[i]
        prev = df.iloc[i - 1]
        date = row["日期"]
        price = row["收盘"]

        # KDJ金叉（K上穿D）且 K < 30 → 买入
        if (prev["K"] < prev["D"] and row["K"] > row["D"] and
            row["K"] < 30 and engine.position == 0):
            engine.buy(date, price)

        # KDJ死叉（K下穿D）且 K > 70 → 卖出
        elif (prev["K"] > prev["D"] and row["K"] < row["D"] and
              row["K"] > 70 and engine.position > 0):
            engine.sell(date, price)

        engine.record_daily(date, price)

    if engine.position > 0:
        last = df.iloc[-1]
        engine.sell(last["日期"], last["收盘"])

    stats = engine.get_stats()
    stats["策略"] = "KDJ低位金叉/高位死叉"
    return stats


def backtest_dual_ma(df: pd.DataFrame, initial_capital: float = 100000) -> dict:
    """双均线策略（MA20/MA60）"""
    return backtest_ma_cross(df, short=20, long=60, initial_capital=initial_capital)


STRATEGIES = {
    "MA5/MA20": lambda df, cap: backtest_ma_cross(df, 5, 20, cap),
    "MA10/MA30": lambda df, cap: backtest_ma_cross(df, 10, 30, cap),
    "MA20/MA60": backtest_dual_ma,
    "MACD": backtest_macd_strategy,
    "KDJ": backtest_kdj_strategy,
}


def run_backtest(code: str, strategy: str = "MA5/MA20",
                 start_date: str = None, days: int = 365,
                 capital: float = None) -> dict:
    """运行回测"""
    if capital is None:
        capital = CFG["initial_capital"]
    from data.fetcher import get_stock_daily
    if start_date is None:
        start_date = (pd.Timestamp.now() - pd.Timedelta(days=days)).strftime("%Y%m%d")

    df = get_stock_daily(code, start_date=start_date)
    if df.empty:
        return {"error": f"无法获取 {code} 数据"}

    if strategy not in STRATEGIES:
        return {"error": f"未知策略: {strategy}"}

    return STRATEGIES[strategy](df, capital)


def format_backtest_report(result: dict) -> str:
    """格式化回测报告"""
    if "error" in result:
        return f"❌ {result['error']}"

    lines = []
    lines.append("=" * 50)
    lines.append(f"  📈 回测报告 - {result.get('策略', 'Unknown')}")
    lines.append("=" * 50)

    lines.append(f"\n💰 资金:")
    lines.append(f"  初始资金: {result['初始资金']:,.0f}")
    lines.append(f"  最终资金: {result['最终资金']:,.0f}")
    lines.append(f"  总收益: {result['总收益']:+,.0f}")

    lines.append(f"\n📊 收益:")
    lines.append(f"  总收益率: {result['总收益率(%)']:+.2f}%")
    lines.append(f"  年化收益率: {result['年化收益率(%)']:+.2f}%")

    lines.append(f"\n⚠️ 风险:")
    lines.append(f"  最大回撤: {result['最大回撤(%)']:.2f}%")
    lines.append(f"  夏普比率: {result['夏普比率']:.2f}")

    lines.append(f"\n🔄 交易:")
    lines.append(f"  交易次数: {result['交易次数']}")
    lines.append(f"  胜率: {result['胜率(%)']:.1f}%")
    lines.append(f"  盈利/亏损: {result['盈利次数']}/{result['亏损次数']}")
    lines.append(f"  总佣金: {result['总佣金']:,.0f}")
    lines.append(f"  总印花税: {result['总印花税']:,.0f}")

    # 收益评价
    ret = result['总收益率(%)']
    dd = result['最大回撤(%)']
    sharpe = result['夏普比率']

    lines.append(f"\n💡 评价:")
    if ret > 20 and sharpe > 1:
        lines.append("  ⭐ 优秀策略 — 高收益低风险")
    elif ret > 10:
        lines.append("  ✅ 良好策略 — 收益可观")
    elif ret > 0:
        lines.append("  🟡 一般策略 — 正收益但不突出")
    else:
        lines.append("  🔴 策略表现不佳 — 需要优化")

    if dd < -20:
        lines.append("  ⚠️ 最大回撤较大，注意风险控制")

    return "\n".join(lines)
