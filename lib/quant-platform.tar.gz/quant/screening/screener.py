"""
选股模块
多因子选股：价值、成长、动量、质量
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pandas as pd
import numpy as np
from data.fetcher import get_stock_realtime, get_stock_daily
from config import SCREENING as CFG
import time


def screen_by_realtime(filters: dict = None) -> pd.DataFrame:
    """
    基于实时行情筛选股票
    filters: 自定义筛选条件
    """
    if filters is None:
        filters = CFG

    print("📥 获取实时行情数据...")
    df = get_stock_realtime()
    if df.empty:
        print("❌ 无法获取行情数据")
        return pd.DataFrame()

    print(f"  原始股票数: {len(df)}")

    # 排除ST
    if filters.get("exclude_st", True):
        df = df[~df["名称"].str.contains("ST|退", na=False)]
        print(f"  排除ST后: {len(df)}")

    # 排除停牌
    if "成交额" in df.columns:
        df = df[df["成交额"] > 0]
        print(f"  排除停牌后: {len(df)}")

    # 市值筛选
    if "总市值" in df.columns and filters.get("min_market_cap"):
        min_cap = filters["min_market_cap"] * 1e8
        df = df[df["总市值"] >= min_cap]
        print(f"  市值>{filters['min_market_cap']}亿: {len(df)}")

    # PE筛选
    if "市盈率-动态" in df.columns:
        pe_col = "市盈率-动态"
        if filters.get("max_pe"):
            df = df[(df[pe_col] > 0) & (df[pe_col] <= filters["max_pe"])]
        if filters.get("min_pe", 0) > 0:
            df = df[df[pe_col] >= filters["min_pe"]]
        print(f"  PE筛选后: {len(df)}")

    # PB筛选
    if "市净率" in df.columns and filters.get("max_pb"):
        df = df[(df["市净率"] > 0) & (df["市净率"] <= filters["max_pb"])]
        print(f"  PB筛选后: {len(df)}")

    return df


def screen_value_stocks(top_n: int = 20) -> pd.DataFrame:
    """价值选股：低PE + 低PB + 正收益"""
    print("\n🔍 价值选股策略...")
    df = screen_by_realtime()
    if df.empty:
        return df

    # 确保PE和PB有效
    df = df[(df["市盈率-动态"] > 0) & (df["市净率"] > 0)]

    # 价值评分 = PE排名 + PB排名
    df["PE排名"] = df["市盈率-动态"].rank(ascending=True)
    df["PB排名"] = df["市净率"].rank(ascending=True)
    df["价值分"] = (df["PE排名"] + df["PB排名"]).rank(ascending=True)

    # 筛选涨幅不大的（价值股特征）
    df = df[df["涨跌幅"] < 5]

    result = df.nsmallest(top_n, "价值分")
    print(f"  选出 {len(result)} 只价值股")
    return result


def screen_growth_stocks(top_n: int = 20) -> pd.DataFrame:
    """成长选股：高涨幅 + 活跃成交 + 动量"""
    print("\n🔍 成长选股策略...")
    df = screen_by_realtime()
    if df.empty:
        return df

    # 排除ST和PE为负的
    df = df[df["市盈率-动态"] > 0]

    # 成长评分 = 涨幅排名 + 量比排名
    df["涨幅排名"] = df["涨跌幅"].rank(ascending=False)
    if "量比" in df.columns:
        df["量比排名"] = df["量比"].rank(ascending=False)
        df["成长分"] = df["涨幅排名"] * 0.6 + df["量比排名"] * 0.4
    else:
        df["成长分"] = df["涨幅排名"]

    # 筛选涨幅在合理范围的
    df = df[(df["涨跌幅"] > 1) & (df["涨跌幅"] < 9.5)]

    result = df.nsmallest(top_n, "成长分")
    print(f"  选出 {len(result)} 只成长股")
    return result


def screen_momentum_stocks(top_n: int = 20) -> pd.DataFrame:
    """动量选股：强势股 + 持续上涨"""
    print("\n🔍 动量选股策略...")
    df = screen_by_realtime()
    if df.empty:
        return df

    # 条件：今日涨幅 > 2%，换手率适中
    df = df[df["涨跌幅"] > 2]

    if "换手率" in df.columns:
        df = df[(df["换手率"] > 2) & (df["换手率"] < 15)]

    # 动量评分
    df["动量分"] = df["涨跌幅"].rank(ascending=False)
    if "成交量" in df.columns:
        df["量排名"] = df["成交量"].rank(ascending=False)
        df["动量分"] = df["动量分"] * 0.7 + df["量排名"].rank() * 0.3

    result = df.nsmallest(top_n, "动量分")
    print(f"  选出 {len(result)} 只动量股")
    return result


def screen_reversal_stocks(top_n: int = 20) -> pd.DataFrame:
    """反转选股：超跌反弹"""
    print("\n🔍 反转选股策略...")
    df = screen_by_realtime()
    if df.empty:
        return df

    # 条件：近期跌幅大，但有企稳迹象
    df = df[(df["涨跌幅"] > -1) & (df["涨跌幅"] < 3)]  # 今日企稳

    if "60日涨跌幅" in df.columns:
        df = df.sort_values("60日涨跌幅").head(100)  # 60日跌幅最大的100只
    elif "年初至今涨跌幅" in df.columns:
        df = df.sort_values("年初至今涨跌幅").head(100)

    # 筛选PE合理的
    df = df[df["市盈率-动态"] > 0]
    df = df[df["市盈率-动态"] < 50]

    result = df.head(top_n)
    print(f"  选出 {len(result)} 只反转候选")
    return result


def screen_sector_leaders(sector: str = None, top_n: int = 10) -> pd.DataFrame:
    """板块龙头选股"""
    print(f"\n🔍 板块龙头选股{' - ' + sector if sector else ''}...")
    df = screen_by_realtime()
    if df.empty:
        return df

    # 按成交额排序取龙头
    if "成交额" in df.columns:
        df = df.sort_values("成交额", ascending=False)

    # 涨幅前列
    df = df[df["涨跌幅"] > 0]

    result = df.head(top_n)
    print(f"  选出 {len(result)} 只龙头股")
    return result


def screen_low_valuation_quality(top_n: int = 20) -> pd.DataFrame:
    """低估值优质股（综合策略）"""
    print("\n🔍 低估值优质股策略...")
    df = screen_by_realtime()
    if df.empty:
        return df

    df = df[(df["市盈率-动态"] > 0) & (df["市盈率-动态"] < 30)]
    df = df[(df["市净率"] > 0) & (df["市净率"] < 5)]

    # 综合评分
    df["PE分"] = df["市盈率-动态"].rank(ascending=True)
    df["PB分"] = df["市净率"].rank(ascending=True)

    if "换手率" in df.columns:
        df["活跃分"] = df["换手率"].rank(ascending=False)
        df["综合分"] = df["PE分"] * 0.35 + df["PB分"] * 0.35 + df["活跃分"] * 0.3
    else:
        df["综合分"] = df["PE分"] * 0.5 + df["PB分"] * 0.5

    result = df.nsmallest(top_n, "综合分")
    print(f"  选出 {len(result)} 只低估值优质股")
    return result


def format_screening_result(df: pd.DataFrame, strategy: str = "") -> str:
    """格式化选股结果"""
    if df.empty:
        return "❌ 未筛选到符合条件的股票"

    lines = []
    lines.append(f"\n{'='*60}")
    lines.append(f"  🎯 选股结果 - {strategy}")
    lines.append(f"{'='*60}")

    display_cols = ["代码", "名称", "最新价", "涨跌幅", "市盈率-动态", "市净率", "成交额", "换手率"]
    cols = [c for c in display_cols if c in df.columns]

    for i, (_, row) in enumerate(df.iterrows()):
        parts = []
        for c in cols:
            val = row[c]
            if c == "涨跌幅":
                parts.append(f"{val:+.2f}%")
            elif c == "成交额":
                parts.append(f"{val/1e8:.1f}亿")
            elif c == "换手率":
                parts.append(f"{val:.1f}%")
            elif c in ("市盈率-动态", "市净率"):
                parts.append(f"{val:.2f}")
            else:
                parts.append(str(val))

        lines.append(f"  {i+1:>2}. {' | '.join(parts)}")

    return "\n".join(lines)


STRATEGIES = {
    "价值": screen_value_stocks,
    "成长": screen_growth_stocks,
    "动量": screen_momentum_stocks,
    "反转": screen_reversal_stocks,
    "龙头": screen_sector_leaders,
    "低估值优质": screen_low_valuation_quality,
}
