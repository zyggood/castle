#!/usr/bin/env python3
"""
A股量化平台 - 命令行入口
用法:
    python3 main.py analyze <代码>        # 综合分析单只股票
    python3 main.py screen [策略]         # 选股
    python3 main.py signal <代码>         # 买卖信号
    python3 main.py backtest <代码> [策略] # 回测
    python3 main.py score <代码>          # 股票评分
    python3 main.py search <关键词>       # 搜索股票
    python3 main.py top [N]               # 涨幅排行
    python3 main.py report <代码>         # 完整报告
    python3 main.py interactive           # 交互模式

选股策略: 价值/成长/动量/反转/龙头/低估值优质
回测策略: MA5/MA20, MA10/MA30, MA20/MA60, MACD, KDJ
"""

import sys
import os

# 确保项目路径在 sys.path 中
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_DIR)

import pandas as pd
from data.fetcher import (get_stock_daily, get_stock_realtime, search_stock,
                           get_top_stocks, get_stock_name)
from screening.screener import (screen_value_stocks, screen_growth_stocks,
                                 screen_momentum_stocks, screen_reversal_stocks,
                                 screen_sector_leaders, screen_low_valuation_quality,
                                 format_screening_result, STRATEGIES)
from signals.timing import get_timing_signal, format_timing_report
from backtest.engine import run_backtest, format_backtest_report, STRATEGIES as BT_STRATEGIES
from analysis.scoring import comprehensive_score, format_score_card
from report.generator import full_report
from analysis.technical import full_technical_analysis, format_technical_report


def cmd_analyze(code: str):
    """综合分析"""
    print(full_report(code))


def cmd_screen(strategy: str = "低估值优质", top_n: int = 20):
    """选股"""
    print(f"\n🎯 执行选股策略: {strategy}")

    func_map = {
        "价值": lambda: screen_value_stocks(top_n),
        "成长": lambda: screen_growth_stocks(top_n),
        "动量": lambda: screen_momentum_stocks(top_n),
        "反转": lambda: screen_reversal_stocks(top_n),
        "龙头": lambda: screen_sector_leaders(top_n=top_n),
        "低估值优质": lambda: screen_low_valuation_quality(top_n),
    }

    if strategy not in func_map:
        print(f"未知策略: {strategy}")
        print(f"可用策略: {', '.join(func_map.keys())}")
        return

    result = func_map[strategy]()
    print(format_screening_result(result, strategy))


def cmd_signal(code: str):
    """买卖信号"""
    print(f"\n⏰ 分析 {code} 的买卖信号...")
    result = get_timing_signal(code)
    print(format_timing_report(result))


def cmd_backtest(code: str, strategy: str = "MA5/MA20"):
    """回测"""
    print(f"\n📈 回测 {code} - 策略: {strategy}")
    result = run_backtest(code, strategy)
    print(format_backtest_report(result))


def cmd_score(code: str):
    """评分"""
    print(f"\n📊 评分 {code}...")
    result = comprehensive_score(code)
    print(format_score_card(result))


def cmd_search(keyword: str):
    """搜索"""
    print(f"\n🔍 搜索: {keyword}")
    df = search_stock(keyword)
    if df.empty:
        print("未找到结果")
        return
    cols = ["代码", "名称", "最新价", "涨跌幅", "市盈率-动态"]
    cols = [c for c in cols if c in df.columns]
    print(df[cols].to_string(index=False))


def cmd_top(n: int = 20):
    """涨幅排行"""
    print(f"\n🏆 涨幅TOP{n}")
    df = get_top_stocks(n)
    if df.empty:
        print("无法获取数据")
        return
    cols = ["代码", "名称", "最新价", "涨跌幅", "成交额", "换手率"]
    cols = [c for c in cols if c in df.columns]
    print(df[cols].to_string(index=False))


def cmd_report(code: str):
    """完整报告"""
    print(full_report(code))


def cmd_multi_screen():
    """多策略综合选股"""
    print("\n" + "=" * 60)
    print("  🎯 多策略综合选股")
    print("=" * 60)

    all_results = {}
    for strategy_name in ["价值", "成长", "低估值优质"]:
        print(f"\n--- {strategy_name}策略 ---")
        func_map = {
            "价值": lambda: screen_value_stocks(15),
            "成长": lambda: screen_growth_stocks(15),
            "低估值优质": lambda: screen_low_valuation_quality(15),
        }
        try:
            df = func_map[strategy_name]()
            if not df.empty and "代码" in df.columns:
                all_results[strategy_name] = set(df["代码"].tolist())
        except Exception as e:
            print(f"  ⚠️ {strategy_name}策略失败: {e}")

    # 找多策略交叉推荐的股票
    if len(all_results) >= 2:
        codes_list = list(all_results.values())
        common = codes_list[0]
        for s in codes_list[1:]:
            common = common & s

        if common:
            print(f"\n{'='*60}")
            print(f"  ⭐ 多策略交叉推荐 ({len(common)}只)")
            print(f"{'='*60}")
            for code in sorted(common):
                name = get_stock_name(code)
                print(f"  {code} {name}")
        else:
            print("\n  无多策略交叉推荐")
    else:
        print("\n  策略数据不足，无法交叉分析")


def interactive_mode():
    """交互模式"""
    print("\n" + "=" * 50)
    print("  🤖 A股量化平台 - 交互模式")
    print("=" * 50)
    print("""
  命令:
    analyze <代码>    - 综合分析
    screen [策略]     - 选股（价值/成长/动量/反转/龙头/低估值优质）
    signal <代码>     - 买卖信号
    backtest <代码> [策略] - 回测
    score <代码>      - 股票评分
    search <关键词>   - 搜索股票
    top [N]           - 涨幅排行
    report <代码>     - 完整报告
    multi             - 多策略综合选股
    help              - 帮助
    quit              - 退出
    """)

    while True:
        try:
            cmd = input("quant> ").strip()
            if not cmd:
                continue

            parts = cmd.split()
            action = parts[0].lower()

            if action == "quit" or action == "exit":
                print("👋 再见!")
                break
            elif action == "help":
                print(__doc__)
            elif action == "analyze" and len(parts) >= 2:
                cmd_analyze(parts[1])
            elif action == "screen":
                strategy = parts[1] if len(parts) >= 2 else "低估值优质"
                cmd_screen(strategy)
            elif action == "signal" and len(parts) >= 2:
                cmd_signal(parts[1])
            elif action == "backtest" and len(parts) >= 2:
                strategy = parts[2] if len(parts) >= 3 else "MA5/MA20"
                cmd_backtest(parts[1], strategy)
            elif action == "score" and len(parts) >= 2:
                cmd_score(parts[1])
            elif action == "search" and len(parts) >= 2:
                cmd_search(parts[1])
            elif action == "top":
                n = int(parts[1]) if len(parts) >= 2 else 20
                cmd_top(n)
            elif action == "report" and len(parts) >= 2:
                cmd_report(parts[1])
            elif action == "multi":
                cmd_multi_screen()
            else:
                print("❓ 未知命令，输入 help 查看帮助")
        except KeyboardInterrupt:
            print("\n👋 再见!")
            break
        except Exception as e:
            print(f"❌ 错误: {e}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return

    cmd = sys.argv[1].lower()

    if cmd == "interactive":
        interactive_mode()
    elif cmd == "analyze" and len(sys.argv) >= 3:
        cmd_analyze(sys.argv[2])
    elif cmd == "screen":
        strategy = sys.argv[2] if len(sys.argv) >= 3 else "低估值优质"
        cmd_screen(strategy)
    elif cmd == "signal" and len(sys.argv) >= 3:
        cmd_signal(sys.argv[2])
    elif cmd == "backtest" and len(sys.argv) >= 3:
        strategy = sys.argv[3] if len(sys.argv) >= 4 else "MA5/MA20"
        cmd_backtest(sys.argv[2], strategy)
    elif cmd == "score" and len(sys.argv) >= 3:
        cmd_score(sys.argv[2])
    elif cmd == "search" and len(sys.argv) >= 3:
        cmd_search(sys.argv[2])
    elif cmd == "top":
        n = int(sys.argv[2]) if len(sys.argv) >= 3 else 20
        cmd_top(n)
    elif cmd == "report" and len(sys.argv) >= 3:
        cmd_report(sys.argv[2])
    elif cmd == "multi":
        cmd_multi_screen()
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
